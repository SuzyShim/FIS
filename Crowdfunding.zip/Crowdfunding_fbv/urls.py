from django.urls import path

from Crowdfunding_fbv import views

app_name = 'Crowdfunding_fbv'

urlpatterns = [
  path('', views.crowdfunding_InitiatorInfo_list, name='Crowdfunding_InitiatorInfo_list'),
  path('new/', views.crowdfunding_InitiatorInfo_create, name='Crowdfunding_InitiatorInfo_new'),
  path('edit/<int:pk>/', views.crowdfunding_InitiatorInfo_update, name='Crowdfunding_InitiatorInfo_edit'),
  path('delete/<int:pk>/', views.crowdfunding_InitiatorInfo_delete, name='Crowdfunding_InitiatorInfo_delete'),
  
  path('Crowdfunding_project_new', views.crowdfunding_project_create, name='Crowdfunding_project_new'),
  path('Crowdfunding_project_edit/<int:pk>/', views.crowdfunding_project_update, name='Crowdfunding_project_edit'),
  path('Crowdfunding_project_delete/<int:pk>/', views.crowdfunding_project_delete, name='Crowdfunding_project_delete'),

  path('Crowdfunding_user_new', views.crowdfunding_user_create, name='Crowdfunding_user_new'),
  path('Crowdfunding_user_edit/<int:pk>/', views.crowdfunding_user_update, name='Crowdfunding_user_edit'),
  path('Crowdfunding_user_delete/<int:pk>/', views.crowdfunding_user_delete, name='Crowdfunding_user_delete'),
]