from django.db import models
from django.urls import reverse


class Crowdfunding_InitiatorInfo(models.Model):
    initiatorInfo_id = models.CharField(max_length=30,verbose_name='发起人id')
    initiatorInfo_credit = models.IntegerField(verbose_name='信用分')
    initiatorInfo_companyAddress = models.CharField(max_length=60,verbose_name='公司地址')
    initiatorInfo_telephone = models.CharField(max_length=60,verbose_name='联系方式')
    initiatorInfo_bankAccount = models.CharField(max_length=30,verbose_name='银行账户')
    initiatorInfo_userID = models.CharField(max_length=30,verbose_name='用户id')
    
    class Meta:
        ordering = ["-initiatorInfo_id"]

    def __str__(self):
        return self.initiatorInfo_id


class Crowdfunding_project(models.Model):
    project_id = models.CharField(max_length=30,verbose_name='项目id')
    project_type = models.CharField(max_length=60,verbose_name='项目类别')
    project_name = models.CharField(max_length=60,verbose_name='项目名称')
    project_details = models.CharField(max_length=60,verbose_name='项目简介')
    project_deadline = models.CharField(max_length=60,verbose_name='筹资期限')
    project_NumOfFollowers = models.IntegerField(verbose_name='关注人数')
    project_feedback = models.CharField(max_length=60,verbose_name='回报内容')
    project_initiatorInfoID = models.ForeignKey(Crowdfunding_InitiatorInfo, on_delete=models.CASCADE,verbose_name='发起人id')

    def __str__(self):
        return self.project_id

    def get_absolute_url(self):
        return reverse('Crowdfunding_fbv:Crowdfunding_project_edit', kwargs={'pk': self.pk})

class Crowdfunding_user(models.Model):
    user_id = models.CharField(max_length=30,verbose_name='用户id')
    user_address = models.CharField(max_length=60,verbose_name='收货地址')
    user_telephone = models.CharField(max_length=60,verbose_name='联系方式')
    user_bankAccount = models.CharField(max_length=30,verbose_name='支付账户')
    user_orderNumber = models.CharField(max_length=60,verbose_name='订单号')
    user_supportProjectID = models.ForeignKey(Crowdfunding_project, on_delete=models.CASCADE,verbose_name='项目id')

    def __str__(self):
        return self.user_id

    def get_absolute_url(self):
        return reverse('Crowdfunding_fbv:Crowdfunding_user_edit', kwargs={'pk': self.pk})

