from django.shortcuts import render, redirect, get_object_or_404
from django.forms import ModelForm

from .models import Crowdfunding_InitiatorInfo, Crowdfunding_project, Crowdfunding_user
from .forms import Crowdfunding_InitiatorInfoForm, Crowdfunding_projectForm, Crowdfunding_userForm



def crowdfunding_InitiatorInfo_list(request):
    template_name='Crowdfunding_fbv/Crowdfunding_InitiatorInfo_list.html'
    crowdfunding_InitiatorInfo = Crowdfunding_InitiatorInfo.objects.all()
    crowdfunding_project = Crowdfunding_project.objects.all()
    crowdfunding_user = Crowdfunding_user.objects.all()
    
    return render(request, template_name, {'crowdfunding_InitiatorInfos':crowdfunding_InitiatorInfo,'crowdfunding_projects':crowdfunding_project,'crowdfunding_users':crowdfunding_user})

def crowdfunding_InitiatorInfo_create(request):
    template_name='Crowdfunding_fbv/Crowdfunding_InitiatorInfo_form.html'
    form = Crowdfunding_InitiatorInfoForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    return render(request, template_name, {'form':form})

def crowdfunding_InitiatorInfo_update(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_InitiatorInfo_form.html'
    crowdfunding_InitiatorInfo= get_object_or_404(Crowdfunding_InitiatorInfo, initiatorInfo_id=pk)
    form = Crowdfunding_InitiatorInfoForm(request.POST or None, instance=crowdfunding_InitiatorInfo)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    return render(request, template_name, {'form':form})

def crowdfunding_InitiatorInfo_delete(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_InitiatorInfo_confirm_delete.html'
    
    crowdfunding_InitiatorInfo= get_object_or_404(Crowdfunding_InitiatorInfo, initiatorInfo_id=pk)    
    if request.method=='POST':
        crowdfunding_InitiatorInfo.delete()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    return render(request, template_name, {'object':crowdfunding_InitiatorInfo})

# ============ Crowdfunding_project CRUD ===============

def crowdfunding_project_create(request):
    template_name='Crowdfunding_fbv/Crowdfunding_project_form.html'
    form = Crowdfunding_projectForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'form': form,
    }
    return render(request, template_name, ctx)

def crowdfunding_project_update(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_project_form.html'
    crowdfunding_project = get_object_or_404(Crowdfunding_project, project_id=pk)
    form = Crowdfunding_projectForm(request.POST or None, instance=crowdfunding_project)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'form': form,
    }
    return render(request, template_name, ctx)

def crowdfunding_project_delete(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_project_confirm_delete.html'
    crowdfunding_project= get_object_or_404(Crowdfunding_project, project_id=pk)    
    if request.method=='POST':
        crowdfunding_project.delete()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'crowdfunding_project': crowdfunding_project,
    }
    return render(request, template_name, ctx)

# ============ Crowdfunding_user CRUD ===============

def crowdfunding_user_create(request):
    template_name='Crowdfunding_fbv/Crowdfunding_user_form.html'
    form = Crowdfunding_userForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'form': form,
    }
    return render(request, template_name, ctx)

def crowdfunding_user_update(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_user_form.html'
    crowdfunding_user = get_object_or_404(Crowdfunding_user, user_id=pk)
    form = Crowdfunding_userForm(request.POST or None, instance=crowdfunding_user)
    if form.is_valid():
        form.save()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'form': form,
    }
    return render(request, template_name, ctx)

def crowdfunding_user_delete(request, pk):
    template_name='Crowdfunding_fbv/Crowdfunding_user_confirm_delete.html'
    crowdfunding_user= get_object_or_404(Crowdfunding_user, user_id=pk)    
    if request.method=='POST':
        crowdfunding_user.delete()
        return redirect('Crowdfunding_fbv:Crowdfunding_InitiatorInfo_list')
    ctx = {
        'crowdfunding_user': crowdfunding_user,
    }
    return render(request, template_name, ctx)
