from django.contrib import admin

from .models import Crowdfunding_InitiatorInfo, Crowdfunding_project, Crowdfunding_user

# Register your models here.
admin.site.register(Crowdfunding_InitiatorInfo)
admin.site.register(Crowdfunding_project)
admin.site.register(Crowdfunding_user)
