from django.apps import AppConfig


class CrowdfundingFbvConfig(AppConfig):
    name = 'Crowdfunding_fbv'
