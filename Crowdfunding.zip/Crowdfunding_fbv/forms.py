from django.forms import ModelForm

from .models import Crowdfunding_InitiatorInfo, Crowdfunding_project, Crowdfunding_user

class Crowdfunding_InitiatorInfoForm(ModelForm):
    class Meta:
        model = Crowdfunding_InitiatorInfo
        fields = '__all__'

class Crowdfunding_projectForm(ModelForm):
    class Meta:
        model = Crowdfunding_project
        fields = '__all__'

class Crowdfunding_userForm(ModelForm):
    class Meta:
        model = Crowdfunding_user
        fields = '__all__'

