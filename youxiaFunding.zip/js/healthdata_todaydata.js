
$bpressure_r="";
$bpressure_s="";


//请求数据   

$.ajax({
    type: "POST",
    url: "php/healthdata_todaydata.php",
    dataType: "json",
    async:false,
    //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
    data: {"phone":$.cookie("phone")},                    
    success: function (data) {
        /*alert(this['healthdata_date']);*/
        $.each(data, function(){
        $weight=this['healthdata_weight'];
        $height=this['healthdata_height'];       
        $bmi=($weight/($height/10000*$height)).toFixed(1);
        $bsuger_e=this['healthdata_bsuger_e'];
        $bsuger_f=this['healthdata_bsuger_f'];
        $bodytemp=this['healthdata_bodytemp'];
        $bpressure=this['healthdata_bpressure_r']+"-"+this['healthdata_bpressure_s'];
        $hrate=this['healthdata_heartRate'];
        $sporttime=this['healthdata_sportingtime'];
        $bpressure_r=this['healthdata_bpressure_r'];
        $bpressure_s=this['healthdata_bpressure_s'];



        document.getElementById("bmi_data").innerHTML=$bmi;
        document.getElementById("weight_data").innerHTML=$weight;
        document.getElementById("bsuger_e_data").innerHTML=$bsuger_e;
        document.getElementById("bsuger_f_data").innerHTML=$bsuger_f;
        document.getElementById("bodytemp_data").innerHTML=$bodytemp;
        document.getElementById("bpressure_data").innerHTML=$bpressure;
        document.getElementById("hrate_data").innerHTML=$hrate;
        document.getElementById("sporttime_data").innerHTML=$sporttime;
        
        

        });    
        /*// 设置表格内容
        $.each(data, function(){
        	str += "<tr class='testRow'>";
            str += "<td class='date'>" + this['healthdata_date'] + "</td>";
            str += "<td class='weight'>" + this['healthdata_weight'] + "</td>";
            str += "<td class='height'>" + this['healthdata_height'] + "</td>";
            str += "<td class='temp'>" + this['healthdata_bodytemp'] + "</td>";
            str += "<td class='bsuger_e'>" + this['healthdata_bsuger_e'] + "</td>";
            str += "<td class='bsuger_f'>" + this['healthdata_bsuger_f'] + "</td>";
            str += "<td class='bpressure_r'>" + this['healthdata_bpressure_r'] + "</td>";
            str += "<td class='bpressure_s'>" + this['healthdata_bpressure_s'] + "</td>";
            str += "<td class='hrate'>" + this['healthdata_heartRate'] + "</td>";
            str += "<td class='sportingtime'>" + this['healthdata_sportingtime'] + "</td>";
            
            str += "</tr>";
        });
        $("#testTable").html(str);
        $(".edit").click(function(){
        	// 得到该条记录中的“first_name”信息
        	var date = $(this).parent().siblings(".date").text();
        	alert(date);
        });*/
    },
    error: function(e) {
		/*alert("failed");*/
        alert(e.responseText);
	}


});

$bmi_value=document.getElementById("bmi_data").innerHTML;
$bsuger_e_value=document.getElementById("bsuger_e_data").innerHTML;
$bodytemp_value=document.getElementById("bodytemp_data").innerHTML;
$bpressure_r_value=$bpressure_r;
$bpressure_s_value=$bpressure_s;
$hrate_value=document.getElementById("hrate_data").innerHTML;
$sporttime_value=document.getElementById("sporttime_data").innerHTML;
if($bmi_value>23.5||$bmi_value<18.5)
{
    document.getElementById("bmi_judge").innerHTML="注意&nbsp;&nbsp;&nbsp;<img id='bmi_img' src='images/attention.png' alt='' style='height:35px'>";
    
}

if($bsuger_e_value>6.1)
{
    document.getElementById("bsuger_judge").innerHTML="注意&nbsp;&nbsp;&nbsp;<img id='bsuger_img' src='images/attention.png' alt='' style='height:35px'>";
    
}

if($bpressure_r_value>89 || $bpressure_r_value<60 || $bpressure_s_value<90 || $bpressure_s_value>139||$hrate_value<60 ||$hrate_value>100)
{
    document.getElementById("bpressure&hrate_judge").innerHTML="注意&nbsp;&nbsp;&nbsp;<img id='bpressure_img' src='images/attention.png' alt='' style='height:35px'>";


}

if($sporttime_value<30)
{
    document.getElementById("sporttime_judge"),innerHTML="过少&nbsp;&nbsp;&nbsp;<img id='sporttime_img' src='images/attention.png' alt='' style='height:35px'>";  


}

if($bodytemp_value<36.1 || $bodytemp_value>37.2)
{
    document.getElementById("bodytemp_judge").innerHTML="注意&nbsp;&nbsp;&nbsp;<img id='bodytemp_img' src='images/attention.png' alt='' style='height:35px'>";

}
