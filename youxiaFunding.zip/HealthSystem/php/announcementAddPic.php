<?php
/*********************************上传标题内容 图片通过base64直接写在内容中***********************************/
    session_start();
    header("content-type:text/html;charset=utf-8");
    require_once('appvars.php');
    require_once('connectvars.php');

   

    if(isset($_POST["title"]))
    {
        $title = $_POST["title"];
    }
    if(isset($_POST["content"]))
    {
        $content = $_POST["content"];
    }
////session获得当前用户并保存在web服务器
    $user = $_SESSION['user'];
    $time = date("Y-m-d H:i:s",time());

    if(isset($_FILES['pictures']))
    {
        $picList = $_FILES['pictures'];
        for($i = 0; $i < count($picList['name']); $i++){
            //不存在当前上传文件则上传
            $target = iconv('utf-8','gb2312',GW_UPLOADPATH2.$picList['name'][$i]);//系统使用的是gb2312编码格式
            if(!file_exists($target)) {
                if(!move_uploaded_file($picList['tmp_name'][$i], "../".$target)){
                    echo json_encode(array("status" => false));
                    return;
                }
            }
        }
    }


   
    $json = array("status"=> false);
    
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

    mysqli_query($dbc,"set character set 'utf8'");
    
    mysqli_query($dbc,"set names 'utf8'");
    if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
      exit();
    }

    $isUpFile = 0;
    $attachmentfile = '';
    if(isset($_FILES['attachmentfile'])){
        $isUpFile = 1;
        $tmp=GW_UPLOADPATH2.time().$_FILES['attachmentfile']['name'];
        $attachmentfile = iconv('utf-8','gb2312',$tmp);
        if(!file_exists($attachmentfile)){
            if(!move_uploaded_file($_FILES['attachmentfile']['tmp_name'], "../".$attachmentfile)){
                echo json_encode(array('status' => false));
                return;
            }
        }
        
    }
    $query = '';
    if($isUpFile == 0)
        $query="insert into announcement (content,sendingtime,title,name) values ('$content','{$time}','$title','$user')";
    else $query = "insert into announcement (content,sendingtime,title,name, file) values ('$content','{$time}','$title','$user', '$tmp')";

    

     if($result=mysqli_query($dbc, $query))
     {
        echo json_encode(array("status"=>true));
     }

    

    // 关闭数据库连接
     mysqli_close($dbc);
    
    

?>