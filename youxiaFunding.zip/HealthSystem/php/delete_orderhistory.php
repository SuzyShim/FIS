<?php
  require_once('appvars.php');
  require_once('connectvars.php');

 if(isset($_POST["order_id"])){
    $order_id = $_POST["order_id"];
  }

    // 连接数据库
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($dbc,"set character set 'utf8'");
    mysqli_query($dbc,"set names 'utf8'");
    if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
      exit();
    }
    // 将要执行的SQL语句
    $query1="delete from orderlist where order_id = '$order_id'";
    $query2="delete from orderlistdetails where order_id = '$order_id'";
    // 执行数据库操作
    $result=mysqli_query($dbc, $query1);
    $result=mysqli_query($dbc, $query2);
    // 关闭数据库连接
    mysqli_close($dbc);

    if($result){
      // 转换成json格式返回
      $json=array('status'=>'success');

    }
    else{
      // 转换成json格式返回
      $json=array('status'=>'fail');

    }

    echo json_encode($json);
?>