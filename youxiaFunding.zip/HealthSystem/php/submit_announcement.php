<?php
/*****************************上传附件*********************************************/
	require_once('appvars.php');
    require_once('connectvars.php');

    //不存在当前上传文件则上传
    $target = null;
    if(!file_exists($target)) {
    	// echo json_encode (move_uploaded_file($_FILES['screenshot']['name'],"uploadFile/"+$_FILES['screenshot']['name']));
    // move_uploaded_file($_FILES['screenshot']['name'],"uploadFile/"+$_FILES['screenshot']['name']);
    	$target = GW_UPLOADPATH1.time().$_FILES['announcementfile']['name'];
       	if(move_uploaded_file($_FILES['announcementfile']['tmp_name'], "../".$target)){
            echo json_encode(array("status"=>true, "filesrc"=>$target));
        }
        else echo json_encode(array("status" => false));
    }
    
?>