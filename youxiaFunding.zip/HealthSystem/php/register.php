<?php
  require_once('appvars.php');
  require_once('connectvars.php');
 $user="";
 $password="";
 $phone="";
  if(isset($_GET["user"])){
    $user = $_GET["user"];  
  }
  if(isset($_GET["password"])){
    $password = $_GET["password"];  
  }
  if(isset($_GET["phone"])){
    $phone = $_GET["phone"];  
  }
  
    // 将要执行的SQL语句
    $query1="select * from user where phone='$phone'";
    $query2="insert into user(phone,user,password,img,age) values ('$phone', '$user', '$password','null','')";
    // 连接数据库
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($conn,"set character set 'utf8'");
    mysqli_query($conn,"set names 'utf8'");
    // 检测连接
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    // 执行数据库操作
    $result_phone = mysqli_query($conn,$query1);
    if($result_phone->num_rows != 0){
       $json=array('status'=>'fail');
    }
    else{
      $result = mysqli_query($conn,$query2);
       $json=array('status'=>'success');
    }

    // 关闭数据库连接
    mysqli_close($conn);
    echo json_encode($json);

?>