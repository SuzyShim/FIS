<?php 
  require_once('appvars.php');
  require_once('connectvars.php');//引入

  if(isset($_POST["index"])){
      $index = $_POST["index"];
  }
  // 连接数据库
    $conn = db_connection(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    $query = "select * from orderlistdetails where order_id = '$index'";
    // 执行查询操作
    $result = $conn->query($query);
    $array = array();
    while($row = mysqli_fetch_array($result)){
          array_push($array, $row);
    }

    echo json_encode($array);
  

  function db_connection($host, $username, $password, $databaseName){
        $conn = mysqli_connect($host, $username, $password, $databaseName);
        // 下面两条语句用来防止中文乱码
      mysqli_query($conn,"set character set 'utf8'");
      mysqli_query($conn,"set names 'utf8'");
        if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
        exit();
        }
        return $conn; // 返回连接对象
    }
 ?>
