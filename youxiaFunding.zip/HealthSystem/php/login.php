<?php
  session_start();
  require_once('appvars.php');
  require_once('connectvars.php');//引入
 $phone="";
 $password="";
  if(isset($_GET["phone"])){
    $phone = $_GET["phone"];  
  }
  if(isset($_GET["password"])){
    $password = $_GET["password"];  
  }
  
    // 将要执行的SQL语句
    $query="select * from user where phone ='$phone' and password = '$password'";
    // 连接数据库
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($conn,"set character set 'utf8'");
    mysqli_query($conn,"set names 'utf8'");
    // 检测连接
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    // 执行数据库操作
    $result = mysqli_query($conn,$query);
    // 关闭数据库连接
    mysqli_close($conn);
    if($result->num_rows == 0){
       $json=array('status'=>'fail');
    }
    else{
       $result=mysqli_fetch_array($result);
       list($phone,$user,$psw,$age,$img,$sex)=$result;//psw是加密过的
       $json=array('status'=>'success','username'=>$user,'age'=>$age,'img'=>$img,'sex'=>$sex);
       $_SESSION["user"] = $user;
       $_SESSION["phone"] = $phone;
       $_SESSION["password"] = $password;
    }
    // print_r($json);
    echo json_encode($json);

?>