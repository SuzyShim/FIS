<?php 
    define('GW_UPLOADPATH', 'uploadFile/');
    define('GW_UPLOADPATH1', 'uploadFile/announcementFile/');
    define('GW_UPLOADPATH2','uploadFile/announcementPic/');
?>
