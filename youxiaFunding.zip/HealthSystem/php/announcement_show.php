<?php 
	
	require_once("connectvars.php");
	

	// $user = $_SESSION['username'];//当前用户
	// $userid = $_SESSION['userid'];//当前用户id
	// $type = $_SESSION['usertype'];//当前用户类型
	$user = 'LiHua';
	$id=1;

	var ok = 1;
	// 首次查询，只需要得到记录数量即可
	if(ok){
		// 连接数据库
		$conn = db_connection(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

		if(ok== 1)
		 {
			$query = "SELECT `title` from announcement WHERE (`sender`='李华')";
			$info = mysqli_query($conn, $query);
			$row = $info->fetch_assoc();

			if($row['sex'] == '女'){
				$query = "SELECT count(*) FROM (SELECT * from announcement WHERE (`sender`='蓝天')) AS B";
			}
			else if($row['sex'] == '男'){
				$query = "SELECT count(*) FROM (SELECT * from announcement WHERE (`sender`='白云')) AS B";
			}
		}
		
		// 执行查询操作
		$result = $conn->query($query);

		echo json_encode(array("total"=>mysqli_fetch_array($result)['0']));
	}
	else{
		// 连接数据库
		$conn = db_connection(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		// 设置偏移记录数，即设置开始行号
		$startRowNum = ($pageIndex-1) * $pageSize;  
		$numOfRows = $pageSize;  // 返回的最多行数

		if($type == 1){
			$query = "SELECT * from (SELECT * from announcement WHERE (`sender`='$user')) AS B order by time desc limit ".$startRowNum.",". $numOfRows;
		}
		else {
			$query = "SELECT `sex` from user_student WHERE (`id`='$userid')";
			$info = mysqli_query($conn, $query);
			$row = $info->fetch_assoc();

			if($row['sex'] == '女'){
				$query = "SELECT * from (SELECT * from announcement WHERE (`sender`='蓝天')) AS B order by time desc limit ".$startRowNum.",". $numOfRows;
			}
			else if($row['sex'] == '男'){
				$query = "SELECT * from (SELECT * from announcement WHERE (`sender`='白云')) AS B order by time desc limit ".$startRowNum.",". $numOfRows;
			}
			
		}
		
		// 执行查询操作
		$result = $conn->query($query);

		$runners = array();
		while($row = mysqli_fetch_array($result, MYSQL_ASSOC)){
	        array_push($runners, $row);
		}

		echo json_encode($runners);
	}
 ?>