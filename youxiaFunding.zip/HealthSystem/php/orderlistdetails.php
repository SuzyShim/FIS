<?php
  require_once('appvars.php');
  require_once('connectvars.php');
  $i=0;
 if(isset($_POST["order_id"])){
    $order_id = $_POST["order_id"];
  }
 if(isset($_POST["i"])){
    $i = $_POST["i"];
  }
  $food_id=array();
  $foodnum=array();
  for($j=0;$j<$i;$j++){
      $tmp1=$_POST['foodid'.$j];
      $food_id[$j]= $tmp1;
      $tmp2= $_POST[$tmp1.'foodnum'];
      $foodnum[$j]= $tmp2;
  }

    // 连接数据库
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($dbc,"set character set 'utf8'");
    mysqli_query($dbc,"set names 'utf8'");
    if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
    exit();
    }
  for($j=0;$j<$i;$j++){
    // 将要执行的SQL语句
    $query="insert into orderlistdetails (order_id,num,food_id) values ('$order_id', '".$foodnum[$j]."', '".$food_id[$j]."')";

    // 执行数据库操作
    $result=mysqli_query($dbc, $query);
  }
    // 关闭数据库连接
    mysqli_close($dbc);

    // 转换成json格式返回
    if($result){
        $json=array('status'=>'success');
    }else{

        $json=array('status'=>'faill');
    }
    echo json_encode($json);



?>