<?php
//声明变量并接受form表单发送过来的数据
session_start();
$date=date("Y-m-d");

$height = $_POST['height'];
$weight = $_POST['weight'];
$bodytemp = $_POST['bodytemp'];
$bpressure_r = $_POST['bpressure_r'];
$bpressure_s = $_POST['bpressure_s'];
$hrate = $_POST['hrate'];
$bsuger_e = $_POST['bsuger_e'];
$bsuger_f = $_POST['bsuger_f'];
$sporttime = $_POST['sporttime'];
$isHealthy=0;
$eatingPlan="";
$sportsPlan="";
$phone = $_SESSION["phone"];
$food=array(
    0=>"早餐：馒头和草莓酱、牛奶（或豆奶）、煮荷包蛋１个、酱黄瓜；
    水果：西红柿或白萝卜１个；
    中餐：荞麦大米饭、香菇菜心、糖醋带鱼、豆腐血旺、丝瓜汤；
    晚餐：绿豆粥、白菜猪肉包子、虾皮冬瓜",

    1=>"早餐：玉米面窝窝头、牛奶（或豆奶）、卤五香茶蛋１个、豆腐乳（１／４块）；
    水果：枇杷（或长生果）３～４个；
    中餐：花生米饭、肉末茄子、葱花土豆泥、鸭子海带汤；
    晚餐：干煸豆角、稀饭、豆沙包、青椒肉丝",

    2=>"早餐：鲜肉包、牛奶（或豆奶）、咸鸭蛋（半个）、素炒三丝（莴笋、白萝卜、胡萝卜）；
    水果：鸭梨一个或西瓜一块；
    中餐：红枣米饭、黄豆烧牛肉、干煸四季豆、金针菇紫菜鸡蛋汤；
    晚餐：三鲜面片（猪肝、火腿肠、黑木耳、平菇）、清炒菠菜、青椒土豆丝",

    3=>"早餐：苹果酱花卷、牛奶（或豆奶）、煮荷包蛋１个、炒泡豇豆；
    水果：香蕉（或黄瓜）１个；
    中餐：米饭（高粱米、白米）、香菇黄花黑木耳肉片、红烧平鱼、白萝卜海带排骨汤；
    晚餐：豆浆或稀饭、葱花煎饼、青椒芹菜肉丝",

    4=>"早餐：酱肉包、牛奶（或豆奶）、素炒三丝（莴笋、白萝卜、胡萝卜）、鹌鹑蛋２个；
    水果：猕猴桃（或桃子）１～２个；
    中餐：红豆米饭、魔芋烧鸭、红椒炒花菜、鱼头香菇冬笋青菜汤；
    晚餐：芹菜猪肉包子、西红柿炒鸡蛋、肉末豆腐脑",

    5=>"早餐：面包、牛奶（或豆奶）、煎鸡蛋1个、卤五香豆腐干；
    水果：草莓（或李子）５～６个；
    中餐：两米饭（大米、小米）、五香鱼、五彩银丝?穴黄豆芽、胡萝卜、莴笋）、鸡腿菇木耳猪肝汤；
    晚餐：玉米粥、鸡蛋发糕、鱼香肉丝"); 

$sport=array(
    0=>"拉伸20min；慢跑20min；游泳20min；5组仰卧起坐12个/组；拉伸20min",
    1=>"拉伸20min；快走40分钟；慢跑20min；6组平板支撑40s/组；拉伸20min",
    2=>"拉伸20min；4组跳绳2min/组；慢跑20min；5组仰卧起坐12个/组；拉伸20min"); 

$bmi=($weight/($height/10000*$height));
if ($bmi>23.9 or $bmi<18.5 or $bsuger_e<3.9 or $bsuger_e>6.1 or $bodytemp<36.1 or $bodytemp>37.2 or $bpressure_r<60 or $bpressure_r>90 or $bpressure_s<90 or $bpressure_s>140 or $hrate<60 or $hrate>100)
{
    $isHealthy=0;
    $sportsPlan=$sport[array_rand($sport,1)];
    $eatingPlan=$food[array_rand($food,1)]; 
}
else{

    $eatingPlan="健康状态不错，请继续保持，按正常饮食习惯即可。";
    $sportsPlan="健康状态不错，请继续保持，按正常运动习惯即可。";
    $isHealthy=1;
}

echo "date:".$date."<br/>"."height:".$height."<br/>"."weight:".$weight."<br/>"."bodytemp:".$bodytemp."<br/>"."bpressure_r:".$bpressure_r."<br/>"."bpressure_s:".$bpressure_s."<br/>"."hrate:".$hrate."<br/>"."bsuger_e:".$bsuger_e."<br/>"."bsuger_f:".$bsuger_f."<br/>"."sporttime:".$sporttime."<br/>"."isHealthy:".$isHealthy."<br/>"."sportsPlan:".$sportsPlan."<br/>"."eatingPlan:".$eatingPlan;


$host = "127.0.0.1";   // 服务器地址 
$username = "root";   // 用户名
$password = "";  // 密码
$databaseName = "web";  // 数据库名
$insert = "replace into personal_healthdata (phone,healthdata_date,healthdata_height,healthdata_weight,healthdata_bodytemp,healthdata_bpressure_r,healthdata_bpressure_s,healthdata_heartRate,healthdata_bsuger_e,healthdata_bsuger_f,healthdata_sportingtime,healthdata_isHealthy,healthdata_sportsPlan,healthdata_eatingPlan) values ('$phone','$date','$height','$weight','$bodytemp','$bpressure_r','$bpressure_s','$hrate','$bsuger_e','$bsuger_f','$sporttime','$isHealthy','$sportsPlan','$eatingPlan')";


$conn = db_connection($host, $username, $password, $databaseName);//连接数据库

if(mysqli_query($conn, $insert))
{
	echo "sucess change!";
}
else
    echo "failed!";
function db_connection($host, $username, $password, $databaseName){
        $conn = mysqli_connect($host, $username, $password, $databaseName);
        // 下面两条语句用来防止中文乱码
        mysqli_query($conn,"set character set 'utf8'");
		mysqli_query($conn,"set names 'utf8'");
        if (mysqli_connect_errno()) {
     		echo "Could not connect to database.";
     		exit();
        }
        else echo "Success connect to database!";
        return $conn; // 返回连接对象
    }

//字符串拼接，打印输出
/*echo $date."<br/>".$height."<br/>".$weight."<br/>".$bodytemp."<br/>".$bpressure_r."<br/>".$bpressure_s."<br/>".$hrate."<br/>".$beforebsuger."<br/>".$afterbsuger."<br/>".$sporttime."<br/>";

//连接数据库
$con = db_connection("localhost","root","","web");
if($con){
echo "<br/>连接成功"."<br/>";
} else{
echo "<br/>连接失败".mysql_error();
}

//设置mysql字符编码
mysqli_query($con,"set names utf8;");
//insert语句
$insert = "insert into personal_healthdata (healthdata_date,healthdata_height,healthdata_weight,healthdata_bodytemp,healthdata_bpressure_r,healthdata_bpressure_s,healthdata_bsuger_e,healthdata_bsuger_f,healthdata_heartRate,healthdata_isHealthy) values ('$date','$height','$weight','$bodytemp','$bpressure_r','$bpressure_s','$hrate','$beforebsuger','$afterbsuger','$sporttime')";
$res_insert = mysqli_query($con,$insert);
if($res_insert){
echo "<br/>插入成功";
} else {
echo "<br/>插入失败";
}*/
/*//update语句
$update = "update user set username='$username',password='$password',phone='$phone' where id= 20";
//$res_update = mysql_query($update);
//select语句
$select = "select * from user";
$res_select = mysql_query($select);
echo "<table width=600 align='center'><tr><td>id</td><td>username</td><td>password</td><td>phone</td></tr>";
while($row = mysql_fetch_row($res_select)){
echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td></tr>";
}
echo "</table>";*/
echo "<script>window.location=('../page_healthdata_edit.html')</script>";

?>
