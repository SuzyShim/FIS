<?php
  require_once('appvars.php');
  require_once('connectvars.php');

 
  $attachmentName = $_POST['attachmentname'];

  // 定义新的文件名及路径（确保文件名不重复）
  // $screenshot = time().$screenshot;
  // $target = GW_UPLOADPATH.$fileName;
  // 把文件移到目标文件夹中
  // if(move_ _file($_FILES['screenshot']['tmp_name'], $target)){
    // 连接数据库
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    // 将要执行的SQL语句
    $query="INSERT INTO announcement VALUES ('$attachmentName')";
    // 执行数据库操作
  if  (mysqli_query($dbc, $query)){//数据库操作是否执行成功
    // 关闭数据库连接
    mysqli_close($dbc);

    // 转换成json格式返回
    $json=array('status'=>'success','attachmentname'=>$attachmentName);
    echo json_encode($json);
  }
  else{ // 如果文件移动失败，提示信息以json格式返回
    $msg = 'sorry, there was a problem uploading your screen shot image.';
    echo json_encode(array('status'=>'fail', 'message'=>$msg));
  }

  // @unlink($_FILES['screenshot']['tmp_name']);

?>