<?php
session_start();
  require_once('appvars.php');
  require_once('connectvars.php');
  $falg="";
  if(isset($_GET["falg"])){
    $falg = $_GET["falg"];  
  }
$phone = $_SESSION["phone"];
    // 将要执行的SQL语句
    $query1="select healthdata_sportsPlan from personal_healthdata where phone = '$phone' order by healthdata_date DESC limit 0,1";
    $query2="select healthdata_eatingPlan from personal_healthdata where phone = '$phone' order by healthdata_date DESC limit 0,1";
    // 连接数据库
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($conn,"set character set 'utf8'");
    mysqli_query($conn,"set names 'utf8'");
    // 检测连接
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    // 执行数据库操作
    if($falg=="1"){
       $result = mysqli_query($conn,$query1);
       $result=mysqli_fetch_array($result);
       $json=array('status'=>'success','plan'=>$result[0]);
    }
    else if($falg=="2"){
       $result = mysqli_query($conn,$query2);
       $result=mysqli_fetch_array($result);
       $json=array('status'=>'success','plan'=>$result[0]);
    }

    // 关闭数据库连接
    mysqli_close($conn);
    echo json_encode($json);

?>