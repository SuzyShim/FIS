<?php
  require_once('appvars.php');
  require_once('connectvars.php');

 if(isset($_POST["time"])){
    $time = $_POST["time"];
  }

 if(isset($_POST["user"])){
    $user = $_POST["user"];
  }
 if(isset($_POST["tot_price"])){
    $tot_price = $_POST["tot_price"];
  }
 if(isset($_POST["state"])){
    $state = $_POST["state"];
  }
 if(isset($_POST["name"])){
    $name = $_POST["name"];
  }


 if(isset($_POST["address"])){
    $address = $_POST["address"];
  }
 if(isset($_POST["phone"])){
    $phone = $_POST["phone"];
  }
  $id=$user+time();
    // 连接数据库
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($dbc,"set character set 'utf8'");
    mysqli_query($dbc,"set names 'utf8'");
    if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
      exit();
    }
    // 将要执行的SQL语句
    $query="insert into orderlist (order_id,name,order_time,user,state,address,tot_price,phone) values ('$id', '$name','$time', '$user','$state','$address','$tot_price','$phone')";
    // 执行数据库操作
    $result=mysqli_query($dbc, $query);
    // 关闭数据库连接
    mysqli_close($dbc);

    if($result){
      // 转换成json格式返回
      $json=array('status'=>'success','order_id'=>$id);

    }
    else{
      // 转换成json格式返回
      $json=array('status'=>'fail');

    }

    echo json_encode($json);
?>