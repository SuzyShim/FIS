<?php
    header("Content-Type: text/html; charset=utf-8");

    $host = "127.0.0.1";   // 服务器地址 
    $username = "root";   // 用户名
    $password = "";  // 密码
    $databaseName = "web";  // 数据库名

    $conn = db_connection($host, $username, $password, $databaseName);
    
    mysqli_query($conn,"set character set 'utf8'"); 
	mysqli_query($conn,"set names 'utf8'");

	//执行查询操作的SQL语句
	$query = "select name,id from announcement";
	//执行查询操作
	$result = mysqli_query($conn,$query);
	//创建一个空数组 为转化成json格式做准备
	$teacherInfo = array();

	// 遍历查询得到的每条记录
    while($row=mysqli_fetch_array($result,MYSQL_ASSOC)){
		print_r($row);
		echo "<br>";

		array_push($teacherInfo, array("name" => $row["name"], "id" =>  $row["id"]));
	}
	 // $t_data = Helper_Tool::unicodeDecode($teacherInfo);
	 
	 //echo json_encode($teacherInfo);


	function db_connection($host, $username, $password, $databaseName){
        $conn = mysqli_connect($host, $username, $password, $databaseName);
        if (!$conn){
            die("Could not connect to database: " . mysqli_connect_errno());
        }
        return $conn; // 返回连接对象
    }

  ?>