<?php
  require_once('appvars.php');
  require_once('connectvars.php');

  $img = $_POST['screenshot'];
  $phone = $_POST['phone'];

  if (strstr($img,",")){
            $base_img = explode(',',$img);
            $base_img = $base_img[1];
        }
 //  设置文件路径和命名文件名称
   $output_file = time().rand(100,999).'.jpg';
   $path = "../uploadFile/".$output_file;
   //  创建将数据流文件写入我们创建的文件内容中
   $r=file_put_contents($path, base64_decode($base_img));
    if (!$r) {
          $json=array('status'=>'fail');
    }else {
    // 转换成json格式返回
          // 连接数据库
          $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
            // 将要执行的SQL语句
          $query="UPDATE user SET img='$output_file' WHERE phone ='$phone'";//修改头像
            // 执行数据库操作
          mysqli_query($dbc, $query);
            // 关闭数据库连接
          mysqli_close($dbc);
          $json=array('status'=>'success','target'=>$output_file);
    }
    echo json_encode($json);
   // 输出文件
  // print_r($img);




?>