<?php
header("content-type:text/html;charset=utf-8");
  require_once('appvars.php');
  require_once('connectvars.php');
  if(isset($_GET["phone"])){
    $phone = $_GET["phone"];  
  }
    $query="select * from user where phone ='$phone'";
    // 连接数据库
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($conn,"set character set 'utf8'");
    mysqli_query($conn,"set names 'utf8'");
    // 检测连接
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
       $result = mysqli_query($conn,$query);
       $result=mysqli_fetch_array($result);
       list($phone,$user,$psw,$age,$img,$sex)=$result;//psw是加密过的
       $json=array('status'=>'success','username'=>$user,'password'=>$psw,'age'=>$age,'img'=>$img,'sex'=>$sex);
    

    // 关闭数据库连接
    mysqli_close($conn);
    echo json_encode($json);

?>