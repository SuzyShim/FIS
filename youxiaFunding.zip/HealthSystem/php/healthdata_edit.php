<?php 
	

 if(isset($_POST["phone"])){
    $phone = $_POST["phone"];
  }
	$host = "127.0.0.1";   // 服务器地址 
    $username = "root";   // 用户名
    $password = "";  // 密码
    $databaseName = "web";  // 数据库名

	$query = "select * from personal_healthdata  where phone='$phone'order by healthdata_date desc limit 1 ;";
	
	// 连接数据库
	$conn = db_connection($host, $username, $password, $databaseName);
	// 执行查询操作
	$result = $conn->query($query);

if (!$result) {
    printf("Error: %s\n", mysqli_error($conn));
    exit();
}
	$runners = array();
	while($row = mysqli_fetch_array($result)){
        array_push($runners, $row);
	}

	echo json_encode($runners);
	
	function db_connection($host, $username, $password, $databaseName){
        $conn = mysqli_connect($host, $username, $password, $databaseName);
        // 下面两条语句用来防止中文乱码
    	mysqli_query($conn,"set character set 'utf8'");
		mysqli_query($conn,"set names 'utf8'");
        if (mysqli_connect_errno()) {
     		echo "Could not connect to database.";
     		exit();
        }
        return $conn; // 返回连接对象
    }




?>
