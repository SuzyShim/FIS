<?php 
  require_once('appvars.php');
  require_once('connectvars.php');//引入
  $pageIndex='';
  $user='';
  $pageSize='';
	if(isset($_POST["index"])){
  		$pageIndex = $_POST["index"];
	}
	if(isset($_POST["user"])){
  		$user = $_POST["user"];
	}
	if(isset($_POST["size"])){
  		$pageSize = $_POST["size"];
	}
	// 连接数据库
		$conn = db_connection(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	// 首次查询，只需要得到记录数量即可
	if($pageIndex==0){
		$query = "select count(*) from orderlist where user='$user'";
		// 执行查询操作
		$result = $conn->query($query);
		echo json_encode(array("total"=>mysqli_fetch_array($result)['0']));
	}
	else{
		// 设置偏移记录数，即设置开始行号
		$startRowNum = ($pageIndex-1) * $pageSize;  
		$numOfRows = $pageSize;  // 返回的最多行数
		$query = "select * from (select * from orderlist where user='$user'order by id DESC)T limit ".$startRowNum.",". $numOfRows;
		// 执行查询操作
		$result = $conn->query($query);
		$array = array();
		while($row = mysqli_fetch_array($result)){
	        array_push($array, $row);
		}

		echo json_encode($array);
	}
	

	function db_connection($host, $username, $password, $databaseName){
        $conn = mysqli_connect($host, $username, $password, $databaseName);
        // 下面两条语句用来防止中文乱码
    	mysqli_query($conn,"set character set 'utf8'");
		mysqli_query($conn,"set names 'utf8'");
        if (mysqli_connect_errno()) {
     		echo "Could not connect to database.";
     		exit();
        }
        return $conn; // 返回连接对象
    }
 ?>
