<?php
  require_once('appvars.php');
  require_once('connectvars.php');

  $phone = $_POST['phone'];
  $username = $_POST["username"];
  $password;
  $age; 
  $sex; 
 if(isset($_POST["password"])){
    $password = $_POST["password"];
  }

 if(isset($_POST["age"])){
    $age = $_POST["age"];
  }
 if(isset($_POST["sex"])){
    $sex = $_POST["sex"];
  }

    // 连接数据库
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    mysqli_query($dbc,"set character set 'utf8'");
    mysqli_query($dbc,"set names 'utf8'");
    if (mysqli_connect_errno()) {
        echo "Could not connect to database.";
    exit();
    }
    // 将要执行的SQL语句
    $query="UPDATE user SET user='$username',password= '$password',age='$age',sex='$sex' WHERE phone ='$phone'";//修改头像
    // 执行数据库操作
    mysqli_query($dbc, $query);
    // 关闭数据库连接
    mysqli_close($dbc);

    // 转换成json格式返回
    $json=array('status'=>'success');
    echo json_encode($json);



?>