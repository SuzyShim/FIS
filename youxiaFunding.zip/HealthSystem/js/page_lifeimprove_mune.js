 var datas = {
        "falg":"2"
 };
 $.getJSON("php/searchPlan.php",datas, function(json){
                console.log(json);
         // getJSON已经帮我们转换成JSON对象了
                if(json.status=='success'){
                  var list = json.plan.split("；");
                  for(var i =0;i<list.length;i++)
                    $("#food_plan").append("<li>"+list[i]+"</li>");
                }
                else if(json.status=='fail'){
                    alert("加载菜单失败"); 
                }   
       });

var names=new Array("水果沙拉","蔬菜沙拉","小米粥","紫米粥","全麦面包","粗粮套餐",
    "水果酸奶麦片","健康套餐1","健康套餐2","意面");
var price=new Array(23,20,8,8,10,18,15,18,20,25);     

//加载菜单cookie
      get();

  var left = new Vue({
    el: '#left',
    data: {
      items: [
        { name : '沙拉' },
        { name : '粥' },
        { name : '粗粮' },
        { name : '麦片' },
        { name : '菜品' },
        { name : '意面' },
      ]
    }
  });

    $('.content').css('height',$('.right').height());
    $('.left ul li').eq(0).addClass('active');
    $(window).scroll(function(){
      if($(window).scrollTop() >= 100){
        $('.left').css('position','fixed');
        $("#right_content").css('position','fixed');
        $("#right_content").css('position','fixed');
        $("#right_content").css('left','80%');
      }else {
        $('.left').css('position','');
        $("#right_content").css('position','');
      };

      //滚动到标杆位置,左侧导航加active
      $('.right ul li').each(function(){
        var target = parseInt($(this).offset().top-$(window).scrollTop());
        var i = $(this).index();
        if (target<=0) {
          $('.left ul li').removeClass('active');
          $('.left ul li').eq(i).addClass('active');
        }else if($(document).height()==$(window).scrollTop()+$(window).height()){
          $('.left ul li').eq($('.left ul li').length-1).addClass('active');
          }
      });
    });
    $('.left ul li').click(function(){
      var i = $(this).index('.left ul li');
      $('body, html').animate({scrollTop:$('.right ul li').eq(i+1).offset().top-100},500);
    });

    var val=0;
    var sum=0;
    if($.cookie('sum')!=null)
    var sum=$.cookie('sum');
    

    $('.subtract').click(function() {

      if($(this).next().val()>0){
	    	val=parseFloat($(this).next().val())-1;
	    	sum--;
    		$('#shop_sum').val(sum);
	    	$(this).next().val(val);
      //设置cookie  
      $.cookie('mune'+$('.subtract').index(this),val, { expires: 1 });
      $.cookie('sum',sum, { expires: 1 });
    	}
    });

    $('.plus').click(function() {

	    	val=parseFloat($(this).prev().val())+1;
	    	sum++;
    		$('#shop_sum').val(sum);
	    	$(this).prev().val(val);
      //设置cookie  
      $.cookie('mune'+$('.plus').index(this),val, { expires: 1 });
      $.cookie('sum',sum, { expires: 1 });
    });
    function get(){
      for(var i=0;i<names.length;i++){
        if($.cookie('mune'+i)!=null){
        console.log($.cookie('mune'+i));
         $('.subtract').eq(i).next().val($.cookie('mune'+i));

        }
        if($.cookie('sum')!=null)
        $('#shop_sum').val($.cookie('sum'));

      }
    }