var fileList = new Array();
let attachmentList = new Array();

$(document).ready(function() {
    const GW_MAXFILESIZE = 2097152;
    Init();
});

function Init() {
    //var $file_btn =  $("#UploadFile");//添加附件按钮
    //!!!!!!!!!!!这里完全不需要，loadPic本来就已经检测input了，你又设置一个点击事件，相当于让他重复检测，而且事件会累计，哪怕相同也会累积
    //var $pic_btn  = $("#InputFile");//添加图片按钮
    var $submit_btn = $("#submit_btn") //发布公告按钮
    loadFile();
    loadPic();
    $submit_btn.click(submitBtnClick);
}
//////////////////////////公告图片即时显示////////////////////////////////////
/***********************点击添加图片***************************************/
function loadPic() {
    /*******************文件操作并即时显示**********************/
    var canUpload = false;
    var formData = new FormData();

    $(".qmEditorPhoto input").change(function() {
        $.each($('#InputFile')[0].files, function(i, file) {
            var fileSize = $(this)[0].size;
            var fileType = $(this)[0].type;


            // 如果大小和类型符合要求
            if ((fileType == 'image/gif' || fileType == 'image/jpeg' || fileType == 'image/pjpeg' || fileType == 'image/png') && fileSize > 0) {
                // 为表单添加数据

                //fileList用来存图片
                fileList.push(file);
                pic2base64(file, fileList.length - 1);

                canUpload = true;
            } else {
                canUpload = false;
                alert("图像必须是 GIF, JPEG, 或者PNG格式!" + canUpload);
            }
        });

    }); //change事件结束


    /********************************文件上传操作***************************************/
    // $('#submit_btn').unbind('click').click(submit);//防止重复绑定

    // function submit()
    // {
    //     var input_title = $("#announcement-title");//标题栏的内容
    //     var input_text = $("#announcement_text");//内容框的内容
    //     ///////把空格写成换行符
    //     // input_text = input_text.replace(/\n/g,"<br>");
    //     alert(input_text);
    //     /////////////////

    //     if(input_title == ""||input_text == "")
    //     {
    //         alert("请补充标题和内容");
    //         return false; 
    //     }
    //     formData.append('announcement_title',input_title);
    //     formData.append('announcement_text',input_text);

    //     /////Ajax文件上传
    //     $.ajax({
    //         url:'announcementAddPic.php',
    //         async:false,
    //         type:'POST',
    //         data:formData,
    //         contentType:false,
    //         processData:false,
    //         success:function(jsonStr){
    //             var json = JSON.parse(jsonStr);
    //             if(json.status == 'success'){
    //                 alert("发布成功");
    //             }
    //             else{
    //                 alert(json.message);  
    //             }
    //         }//success结束

    //     })//ajax结束

    // }//submit事件结束


} //loadPic结束

/****************************点击添加附件*******************************/
function loadFile() {
    $("#UploadFile").change(function() {
        var formData = new FormData();
        $.each($('#UploadFile')[0].files, function(i, file) {
            var fileSize = $(this)[0].size;
            var fileType = $(this)[0].type;
            var getfile = $('#UploadFile').val();
            var $uploadFile = $("#uploadFile");
            var fileName = file.name;



            // 如果大小和类型符合要求
            if ((fileSize > 0 && fileSize < 2097152)) {
                $uploadFile.empty();
                $uploadFile.html(fileName);
                attachmentList.push(file);
            } //if结束
            else {
                alert("移动添加失败!");
            }
        }); //.each结束
    }); //change结束
} //loadFile结束

function submitBtnClick() {

    var formData = new FormData();
    var title = $("#announcement-title").val().trim();
    var content1 = $("#main_content").html().trim();

    var announcementImg = $("#picture img.edit-pic"); //文本框中所有图片
    var uploadPicList = new Array();
    var fileName = null;
    //修改图片路径
    for (var i = announcementImg.length - 1; i >= 0; i--) {
        //!!!!!!!!这里记错了，应该是dataset,字符串转int
        var index = parseInt(announcementImg[i].dataset.index); //index存当前图片的data-index标识
        fileName = new Date().getTime().toString() + fileList[index].name;
        //!!!!!!!!!!!!!@!@!!@@!#@!#@#@@!@!#@@#!@!##@#@!
        announcementImg[i].src = "uploadFile/announcementPic/" + fileName //.attr('src', "announcementPic/"+fileName);//变成数组后都是js元素了，就用js的方法了
        $(announcementImg[i]).attr('class', 'uploadedPic');

        var file = new File([fileList[index]], fileName, { type: fileList[index].type }); //这里的格式是固定的
        uploadPicList.push(file); //把持有Index的图片对应的file存进uploadlist,uploadlist存要上传的文件
    }
    //foreach!!!#$!$#!#@#@!!@!!!!!!!!
    $.each(uploadPicList, (i, file) => {
        console.log(file);
        formData.append('pictures[]', file);
    });

    var content2 = $("#main_content").html().trim();

    if (title != null && content2 != null && title != '' && content2 != '') {
        formData.append('title', title);
        //！！！！！！！！！！！！！！！
        formData.append('content', content2); //！！！无法获取元素，应用html
    } else {
        $("#main_content").html(content1);
        alert("请填写完整");
        return;
    }


    if (attachmentList.length > 0) {
        formData.append('attachmentfile', attachmentList[attachmentList.length - 1]);
    }

    $.ajax({
        url: 'php/announcementAddPic.php',
        type: 'POST',
        data: formData,
        contentType: false, //不可缺
        processData: false, //不可缺
        success: function(jsonStr) {
                var json = JSON.parse(jsonStr);
                if (json.status) { //在后端status的值为true或false
                    //////测试用
                    $("#main_content").empty();
                    $("#main_content").append(formData.get('content'));
                    $("#announcement-title").val("");
                    $("#main_content").html("");
                    $('#uploadFile').html("");
                    attachmentList = null;
                    uploadPicList = null;
                    attachmentList = new Array();
                    uploadPicList = new Array();

                    alert("发布成功");


                } //if结束
                else if (json.status == 'fail') {
                    $(".error").text(json.message);
                }
            } //success结束

    }); //ajax结束


} //发布按钮结束

/////!!!!!!!!!!@#!@#!!@!@!#!@#
function pic2base64(file, index) { //base64
    var reader = new FileReader();
    reader.onload = e => {
        var textarea = $("#main_content");
        var img = new Image();
        img.src = e.target.result;
        textarea.append(img);
        $(img).attr("data-index", index);
        ////！！！！！！！！！！！！！&**&**&&*^&&*!*(&^&%%^^%!$%^%&)
        $(img)[0].classList.add('edit-pic'); //添加类名，一定要记得这个方法,js的方法所以要从jq转js
    }
    reader.readAsDataURL(file);
}