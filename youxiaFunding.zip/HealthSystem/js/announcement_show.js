var pageIndex = 1;    //页面索引初始值   
var pageSize = 1;     //每页显示条数初始化，修改显示条数，修改这里即可   
var pageCount = 30;   //总的记录数，随便赋个初值好了，后面会重新赋值的 
$(document).ready(function () {
    // alert("11111");
    // 得到要显示的总的记录数 
    $.ajax({
        url: 'php/announcement_showDb.php',
        async: false,  // 取消异步，因为只有先得到总记录数，才能计算实际需要多少页
        type: 'POST',
        dataType: 'json',
        data: {index: 0, size: pageSize}, // 提交数据
        success: function(data){
            // alert("22222");
             pageCount = data.total;
        },
        error: function() {
           alert("1551");
        }
    });
    
    InitNewTable(pageIndex);    //初始化表格数据
    InitPager();
});

function InitPager() {
    //分页，PageCount是总条目数，这是必选参数，其它参数都是可选
    $("#pager").pagination(pageCount, {
        callback: pageCallback,  //PageCallback() 为翻页调用次函数。
        prev_text: "上一页",
        next_text: "下一页",
        items_per_page: pageSize,
        num_edge_entries: 4,       //两侧首尾分页条目数//首位的页面部分（数量）
        num_display_entries: 6,    //连续分页主体部分分页条目数//当前页附近的页面部分
        current_page: pageIndex - 1,   //当前页索引
    });
}
//翻页调用   
function pageCallback(index, jq) {
    InitTable(index + 1);
}
//请求数据   
function InitNewTable(pageIndex) {

    $.ajax({
        details();
         type: "POST",
        url: "php/announcement_showDb.php",
        dataType: "json",
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        data: {index: pageIndex, size: pageSize,sendingname:name},                    
        success: function (data) {
            
            // $("#divtest").html("<table class='table table-hover' id='testTable'></table>");
            // // 设置表格标题
            // // 设置为对应的teacher表
            // var str = "";
            // str += "<thead>"
            // str += "<th class='id'>序号</th>";
            // str += "<th class='title'>标题</th>";  
            // str += "<th class='content'>内容</th>";
            // // str += "<th class='sendingtime'>发送时间</th>";
            // str += "<th class='name'>发布人</th>";
            // str += "<th class='operation'>操作</th>";
            // str += "</thead>";

            // // 设置表格内容
            // $.each(data, function(){
            //     str += "<tbody><tr class='testRow'>";
            //     str += "<td class='id'>" + this['id'] + "</td>";
            //     str += "<td class='title'>" + this['title'] + "</td>";
            //     str += "<td class='content'>" + this['content'] + "</td>";
            //     // str += "<td class='sendingtime'>" + this['sendingtime'] + "</td>";
            //     str += "<td class='name'>" + this['name'] + "</td>";
            //     str += "<td class='operation'><a href='page_announcement_check.html' class='edit'>删除</a></td>";
            //     str += "</tr><tbody>"
            // });
            // $("#testTable").html(str);
            // $("tbody").click(function(){
            //     // 得到该条记录中的“name”信息
               
            //     var name = $(this).parent().siblings(".name").text();
            //     alert(name);
            // });
           
            $("#divtest").html("<div class = 'announcement' id = 'total'</div>");
            //设置为对应的announcement表
            var str = "";
            str +="<div class = 'title'></div>";
            str +="<div class = 'name'></div>";
            str +="<div class = 'sendingtime></div>";
            str += "<div class = 'content'></div>";

            //设置内容
            $.each(data,function(){
                str += "<div class = 'testRow'>";
                str += "<h4><div class = 'title'>" + this['title'] + "</div></h4>";
                str += "<div class = 'name'>"+ this['name'] + "</div>";
                str += "<div class = 'sendingtime'>" + this['sendingtime'] + "</div>";
                str += "<div class = 'content'>" + this['content'] + "</div>";
                str += "</div>";

            });
          $("#total").html(str);
        },
        error: function() {
            alert("22222");
            alert("error");
        }
    });
}

