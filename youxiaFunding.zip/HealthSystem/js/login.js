 $("#password").val($.cookie("password"));
 $("#user_id").val($.cookie("phone"));
 $("#signin button").click(function(){
        var datas = {
                "phone":$("#user_id").val(),
                "password":$("#password").val()
        };
        $.getJSON("php/login.php",datas, function(json){
                console.log(json);
         // getJSON已经帮我们转换成JSON对象了
                if(json.status=='success'){
                    //设置cookie  
                    $.cookie("img",json.img, { expires: 1 });
                    $.cookie("username",json.username, { expires: 1 });
                    $.cookie("age",json.age, { expires: 1 });   
                    $.cookie("sex",json.sex, { expires: 1 });   
                    $.cookie("password",$("#password").val(), { expires: 1 });   
                    $.cookie("phone",$("#user_id").val(), { expires: 1 });


                    // 跳转页面
                    location.href="page_healthdata.html";
                }
                else if(json.status=='fail'){
                    alert("账户或密码错误，请重新输入"); 
                }   
       });

    });
