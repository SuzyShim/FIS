//请求数据   

$.ajax({
    type: "POST",
    url: "php/healthdata_edit.php",
    dataType: "json",
    //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
    data: {"phone":$.cookie("phone")},                    
    success: function (data) {
        /*alert(this['healthdata_date']);*/
        $.each(data, function(){
        $weight=this['healthdata_weight'];
        $height=this['healthdata_height'];       
        $bsuger_e=this['healthdata_bsuger_e'];
        $bsuger_f=this['healthdata_bsuger_f'];
        $bodytemp=this['healthdata_bodytemp'];
        $bpressure_r=this['healthdata_bpressure_r'];
        $bpressure_s=this['healthdata_bpressure_s'];
        $hrate=this['healthdata_heartRate'];
        $sporttime=this['healthdata_sportingtime'];



        document.getElementById("height").value=$height;

        document.getElementById("weight").value=$weight;
        document.getElementById("bsuger_e").value=$bsuger_e;
        document.getElementById("bsuger_f").value=$bsuger_f;
        document.getElementById("bodytemp").value=$bodytemp;
        document.getElementById("bpressure_r").value=$bpressure_r;
        document.getElementById("bpressure_s").value=$bpressure_s;
        document.getElementById("hrate").value=$hrate;
        document.getElementById("sporttime").value=$sporttime;
        
        

        });    
        /*// 设置表格内容
        $.each(data, function(){
        	str += "<tr class='testRow'>";
            str += "<td class='date'>" + this['healthdata_date'] + "</td>";
            str += "<td class='weight'>" + this['healthdata_weight'] + "</td>";
            str += "<td class='height'>" + this['healthdata_height'] + "</td>";
            str += "<td class='temp'>" + this['healthdata_bodytemp'] + "</td>";
            str += "<td class='bsuger_e'>" + this['healthdata_bsuger_e'] + "</td>";
            str += "<td class='bsuger_f'>" + this['healthdata_bsuger_f'] + "</td>";
            str += "<td class='bpressure_r'>" + this['healthdata_bpressure_r'] + "</td>";
            str += "<td class='bpressure_s'>" + this['healthdata_bpressure_s'] + "</td>";
            str += "<td class='hrate'>" + this['healthdata_heartRate'] + "</td>";
            str += "<td class='sportingtime'>" + this['healthdata_sportingtime'] + "</td>";
            
            str += "</tr>";
        });
        $("#testTable").html(str);
        $(".edit").click(function(){
        	// 得到该条记录中的“first_name”信息
        	var date = $(this).parent().siblings(".date").text();
        	alert(date);
        });*/
    },
    error: function(e) {
		/*alert("failed");*/
        alert(e.responseText);
	}
});

