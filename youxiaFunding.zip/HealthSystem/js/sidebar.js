 
getCookie();

$("#brand").append("<label id='loginout' style='font-size: 14px; margin-left: 78%; font-weight: bold;'><img src='images/loginout.svg' style='width: 20px;'> 注销</label>");
// 侧边栏
 $("#sidebar_menu>li>a").click(function(){
            $("#sidebar_menu li a").removeClass("active");
            $("#img_list1").attr("src", "images/list_1.png");
            $("#img_list2").attr("src", "images/list_1.png");
            //下拉栏隐藏
            $("#list_announcement").hide();
            $("#list_healthlife").hide();

            $(this).addClass("active");
            $(this).children().next().next().attr("src", "images/list_2.png");
            $(this).next().show();//下拉栏出现
      });

      $("#sidebar_menu>li>a").hover(function(){
        $(this).toggleClass("hover");
    });

 $("#loginout").click(function(){
    var r=confirm("确定要退出登录吗？");
    if (r==true){
       $.cookie('phone',null);
       $.cookie('username',null);
       $.cookie('password',null);
       $.cookie('age',null);
       $.cookie('img',null);
       $.cookie('sex',null);
        location.href="login.html";
        alert("退出成功");
    }
});
function getCookie(){ //获取cookie  =
                var phone=$.cookie("phone");
                if(phone==null){
                    // 跳转页面 
                    alert("请先登录");
                    location.href="login.html";

                }
                if(phone=='null'){
                    // 跳转页面 
                    alert("请先登录");
                    location.href="login.html";

                }
                $('#user_id').html($.cookie("username"));
                var img=$.cookie("img");
                if(img!='null'){
                     $("#user img").attr("src", "uploadFile/"+img);
                }

}