
var names=new Array("水果沙拉","蔬菜沙拉","小米粥","紫米粥","全麦面包","粗粮套餐",
    "水果酸奶麦片","健康套餐1","健康套餐2","意面");
var price=new Array(23,20,8,8,10,18,15,18,20,25);

$("#headbar img").click(function(){
	// window.history.go(-1); //返回上一页
	location.href="page_lifeimprove_mune.html";
});

var tmp=0;
var sum_pirce=0;
var index=new Array();
for(var i=0;i<names.length;i++){
    if($.cookie('mune'+i)!=null&&$.cookie('mune'+i)!='0'){
	index[tmp]=i;
	tmp++;
	console.log($.cookie('mune'+i));
	$('#content').append("<div class='list'><label class='food_name'>"+names[i]+"<span class='price'>￥"+price[i]+"</span>"+
		"</label><div class='add form-inline'>"+"<img class='subtract' src='images/subtract_green.png'>"+
      "<input  disabled='disabled' value='"+$.cookie('mune'+i)+"'><img class='plus' src='images/add_green.png'></div></div>");
	sum_pirce+=price[i]*$.cookie('mune'+i);

	}
 }

	$('#content').append("<div id='sum_price'>总价：￥"+sum_pirce+"</div>");
	$('#content').append("<button id='submit' data-toggle='modal' data-target='#avatar-modal' >提交</button>");

    var val=0;
    var sum=0;
    if($.cookie('sum')!=null)
    var sum=$.cookie('sum');
	//减按钮
    $('.subtract').click(function() {

      if($(this).next().val()>0){
	    	val=parseFloat($(this).next().val())-1;
	    	sum--;
	    	$(this).next().val(val);
    	}

      //设置cookie  
      $.cookie('mune'+index[$('.subtract').index(this)],val, { expires: 1 });
      $.cookie('sum',sum, { expires: 1 });

	sum_pirce-=price[index[$('.subtract').index(this)]];
      if($(this).next().val()==0){
      		index.splice($('.subtract').index(this),1);
    		$(this).parent().parent().remove();
      }

	    	$('#sum_price').html("总价：￥"+sum_pirce);

    });
    //加按钮
    $('.plus').click(function() {

	    	val=parseFloat($(this).prev().val())+1;
	    	sum++;
	    	$(this).prev().val(val);

		      //设置cookie  
		      $.cookie('mune'+index[$('.plus').index(this)],val, { expires: 1 });
		      $.cookie('sum',sum, { expires: 1 });

	    	// console.log($('.plus').index(this));
			sum_pirce+=parseFloat(price[index[$('.plus').index(this)]]);
	    	$('#sum_price').html("总价：￥"+sum_pirce);
    });


			//模态框取消
			$('.addbtn_no').click(function() {
					// $(".movemodal").fadeOut(600);
					$(".movemodal").modal('hide');
    
   			 });
			$('.addbtn_ok').click(function() {

				var address=$('#province1').val()+$('#city1').val()+$('#district1').val()+$('#detail').val();
				if($('#detail').val()==''||$('#province1').val()==''||$('#buyer_name').val()==''||$('#buyer_phone').val()==''){
					alert('请填写完整信息');
					return false;
				}
				 else if(!isphone($("#buyer_phone").val())){
			        alert("请检查您的手机格式");
			     	 $('#buyer_phone').focus();
					return false;
			    }
			var listdetailData = new FormData();
                    var listData = new FormData();
                    listData.append("time", getNowTime());
                    listData.append("name", $('#buyer_name').val());
                    listData.append("user", $.cookie('phone'));
                    listData.append("address", address);
                    listData.append("phone", $('#buyer_phone').val());
                    listData.append("tot_price", sum_pirce);
                    listData.append("state", '已接单');
                    var order_id;
					$.ajax({
                                url: 'php/orderlist.php',
                                type: 'POST',
                                data: listData,
                                contentType: false,    //不可缺
                                processData: false,    //不可缺
                                success: function(jsonStr){
                                    var json = JSON.parse(jsonStr);
                                    if(json.status=='success'){

												var temp=0;
												$(".plus").each(function(i,e){
										   			listdetailData.append('foodid'+i,index[i]);
										    		listdetailData.append(index[i]+'foodnum',$(this).prev().val());
										    		temp++;
										        });
			   									listdetailData.append('order_id',json.order_id);

										   		listdetailData.append('i',temp);//长度
												$.ajax({
					                                url: 'php/orderlistdetails.php',
					                                type: 'POST',
					                                data: listdetailData,
					                                contentType: false,    //不可缺
					                                processData: false,    //不可缺
					                                success: function(jsonStr){
					                                    var json = JSON.parse(jsonStr);
					                                    if(json.status=='success'){
					                                        alert("您的订单已经成功提交！马上送货，请耐心等待");
															$(".movemodal").modal('hide');
					                                    }
					                                    else if(json.status=='fail'){
					                                        // $(".error").text(json.message); 
					                                    }   
					                                },
					                                error: function(){
					                                    alert("error");
					                                }
					                            }); // ajax上orderlistdetail结束
    
                                    }
                                    else if(json.status=='fail'){
                                        // $(".error").text(json.message); 
                                    }   
                                },
                                error: function(){
                                    alert("error");
                                }
                            }); // ajax上orderlist结束

   			 });


						



			function getNow(s) {
			    return s < 10 ? '0' + s: s;
			}
			function getNowTime(){

						var myDate = new Date();
						//获取当前年
						var year=myDate.getFullYear();
						//获取当前月
						var month=myDate.getMonth()+1;
						//获取当前日
						var date=myDate.getDate(); 
						var h=myDate.getHours();       //获取当前小时数(0-23)
						var m=myDate.getMinutes();     //获取当前分钟数(0-59)
						var s=myDate.getSeconds();  

						var now=year+'-'+getNow(month)+"-"+getNow(date)+" "+getNow(h)+':'+getNow(m)+":"+getNow(s);
						return now;
			}
	function isphone(TEL) {
         var reg =/^(13[0-9]{9})|(15[0-9]{9})|(17[0-9]{9})|(18[0-9]{9})|(19[0-9]{9})$/;
        if (TEL.match(reg)) {
            return true;
        }
        return false;
    }