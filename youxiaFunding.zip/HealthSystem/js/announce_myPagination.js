var pageIndex = 1; //页面索引初始值   
var pageSize = 7; //每页显示条数初始化，修改显示条数，修改这里即可   
var pageCount = 30; //总的记录数，随便赋个初值好了，后面会重新赋值的 

//获取输入文本框中的内容
var searchingword = $("#searchs").val();
var announcetitle;
var announceid;

$(document).ready(function() {
    // $('#details').hide();
    // 得到要显示的总的记录数 
    $.ajax({
        url: 'php/connectDB_announce.php',
        async: false, // 取消异步，因为只有先得到总记录数，才能计算实际需要多少页
        type: 'POST',
        dataType: 'json',
        data: { index: 0, size: pageSize }, // 提交数据
        success: function(data) {
            pageCount = data.total;
        },
        error: function() {
            alert("error");
        }
    });

    InitTable(pageIndex); //初始化表格数据
    InitPager();
    search();
    $("#backs").bind("click");
    $("#backs").click(() => {
        back();
    });


    search(searchingword);
    // InitTable1(pageIndex); 
});

function deleteannounce(announcetitle) {


    alert("delete!");
    $.ajax({

        type: "POST",
        url: "php/deleteannounce_showDb.php",
        dataType: "json",
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        // data: {index: pageIndex, size: pageSize,sendingname:name},
        data: { announcetitle: announcetitle }, // 提交数据                    
        success: function(data) {
            console.log(data);

        }, //succes结束
        error: function() {
            //alert("22222");
        }
    }); //ajax结束

}

function InitPager() {
    //分页，PageCount是总条目数，这是必选参数，其它参数都是可选
    $("#pager").pagination(pageCount, {
        callback: pageCallback, //PageCallback() 为翻页调用次函数。
        prev_text: "上一页",
        next_text: "下一页",
        items_per_page: pageSize,
        num_edge_entries: 4, //两侧首尾分页条目数//首位的页面部分（数量）
        num_display_entries: 6, //连续分页主体部分分页条目数//当前页附近的页面部分
        current_page: pageIndex - 1, //当前页索引
    });
}
//翻页调用   
function pageCallback(index, jq) {
    InitTable(index + 1);
}
//获取Id


/************************************编辑公告**************************************************/
function edit(id) {
    //////////////获取id值。赋给announceid
    console.log($("#InputFile").attr('name'));
    announceid = id;
    var fileList = new Array();
    let attachmentList = new Array();


    const GW_MAXFILESIZE = 2097152;


    console.log("init");
    //var $file_btn =  $("#UploadFile");//添加附件按钮
    //!!!!!!!!!!!这里完全不需要，loadPic本来就已经检测input了，你又设置一个点击事件，相当于让他重复检测，而且事件会累计，哪怕相同也会累积
    //var $pic_btn  = $("#InputFile");//添加图片按钮
    var $submit_btn = $("#submit_btn") //发布公告按钮
    loadFile();
    loadPic();
    $submit_btn.bind("click");
    $submit_btn.click(submitBtnClick);
    //////////////////////////公告图片即时显示////////////////////////////////////
    /***********************点击添加图片***************************************/
    function loadPic() {
        console.log("loadPic");
        /*******************文件操作并即时显示**********************/
        var canUpload = false;

        $("#InputFile").change(function() {
            console.log("loadPicclick");
            $.each($('#InputFile')[0].files, function(i, file) {
                var fileSize = $(this)[0].size;
                var fileType = $(this)[0].type;


                // 如果大小和类型符合要求
                if ((fileType == 'image/gif' || fileType == 'image/jpeg' || fileType == 'image/pjpeg' || fileType == 'image/png') && fileSize > 0) {
                    // 为表单添加数据

                    //fileList用来存图片
                    fileList.push(file);
                    pic2base64(file, fileList.length - 1);

                    canUpload = true;
                } else {
                    canUpload = false;
                    alert("图像必须是 GIF, JPEG, 或者PNG格式!" + canUpload);
                }
            });

        }); //change事件结束


    } //loadPic结束

    /****************************点击添加附件*******************************/
    function loadFile() {
        console.log("loadfile1");

        $("#UploadFile").change(function() {
            console.log("loadfile");
            var formData = new FormData();
            $.each($('#UploadFile')[0].files, function(i, file) {
                var fileSize = $(this)[0].size;
                console.log(fileSize);
                var fileType = $(this)[0].type;
                var $uploadFile = $(".edit-attachment");
                var fileName = file.name;
                var str = "<a class='edit-attachment-file'>" + fileName + "</a>";
                $uploadFile.empty();
                $uploadFile.html("");
                $uploadFile.html(fileName);


                // 如果大小和类型符合要求
                if ((fileSize > 0 && fileSize < 83886080)) {
                    attachmentList.push(file);
                } //if结束
                else {
                    alert("移动添加失败!");
                }
            }); //.each结束
        }); //change结束
    } //loadFile结束

    function submitBtnClick() {
        alert("提交");
        var formData = new FormData();
        var title = $(".edit-title").text().trim();
        var content1 = $(".edit-content").html().trim();

        var announcementImg = $(".edit-content img.edit-pic"); //文本框中所有图片
        var uploadPicList = new Array();
        var fileName = null;
        //修改图片路径
        for (var i = announcementImg.length - 1; i >= 0; i--) {
            //!!!!!!!!这里记错了，应该是dataset,字符串转int
            var index = parseInt(announcementImg[i].dataset.index); //index存当前图片的data-index标识
            fileName = new Date().getTime().toString() + fileList[index].name;
            //!!!!!!!!!!!!!@!@!!@@!#@!#@#@@!@!#@@#!@!##@#@!
            announcementImg[i].src = "uploadFile/announcementPic/" + fileName //.attr('src', "announcementPic/"+fileName);//变成数组后都是js元素了，就用js的方法了
            $(announcementImg[i]).attr('class', 'uploadedPic');

            var file = new File([fileList[index]], fileName, { type: fileList[index].type }); //这里的格式是固定的
            uploadPicList.push(file); //把持有Index的图片对应的file存进uploadlist,uploadlist存要上传的文件
        }
        //foreach!!!#$!$#!#@#@!!@!!!!!!!!
        $.each(uploadPicList, (i, file) => {
            console.log(file);
            formData.append('pictures[]', file);
        });

        var content2 = $(".edit-content").html().trim();

        if (title != null && content2 != null && title != '' && content2 != '') {
            formData.append('title', title);
            //！！！！！！！！！！！！！！！
            formData.append('content', content2); //！！！无法获取元素，应用html
        } else {
            $(".content").html(content1);
            alert("请填写完整");
            return;
        }
        formData.append('announceid', announceid);
        if (attachmentList.length > 0) {
            formData.append('attachmentfile', attachmentList[attachmentList.length - 1]);
        }



        $.ajax({
            url: 'php/editannounce.php',
            type: 'POST',
            data: formData,
            contentType: false, //不可缺
            processData: false, //不可缺
            success: function(jsonStr) {
                jsonStr = $.parseJSON(jsonStr);
                console.log(jsonStr);
                if (jsonStr[0].status) {
                    alert("编辑成功！");
                    $("a.edit-attachment-file").attr('class', 'uploaded-attachment-file');
                    setTimeout(() => {
                        InitTable1(announceid);
                    }, 1000);



                } else {
                    alert("error:" + jsonStr[0].message);
                }

                // $("#total").html(str);
            }, //success结束
            error: function() {
                //alert("22222");
                alert("error");
            }
        }); //ajax结束


    } //发布按钮结束

    /////!!!!!!!!!!@#!@#!!@!@!#!@#
    function pic2base64(file, index) { //base64
        var reader = new FileReader();
        reader.onload = e => {
            var textarea = $(".edit-content");
            var img = new Image();
            img.src = e.target.result;
            textarea.append(img);
            $(img).attr("data-index", index);
            ////！！！！！！！！！！！！！&**&**&&*^&&*!*(&^&%%^^%!$%^%&)
            $(img)[0].classList.add('edit-pic'); //添加类名，一定要记得这个方法,js的方法所以要从jq转js
        }
        reader.readAsDataURL(file);
    }


} //edit结束
/************************************显示初始目录****************************************/
//请求数据 ,初始的目录表格  
function InitTable(pageIndex) {
    $.ajax({
        type: "POST",
        url: "php/connectDB_announce.php",
        dataType: "json",
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        data: { index: pageIndex, size: pageSize },
        success: function(data) {
            console.log(data[0]);
            $("#divtest").html("<table class='table table-hover' id='testTable'></table>");
            // 设置表格标题
            // 设置为对应的teacher表
            var str = "";
            str += "<thead>"
            str += "<th class='id'>序号</th>";
            str += "<th class='title'>标题</th>";
            // str += "<th class='content'>内容</th>";
            str += "<th class='sendingtime'>发送时间</th>";
            str += "<th class='name'>发布人</th>";
            str += "<th class='operation'>操作</th>";
            str += "</thead>";

            // 设置表格内容
            $.each(data, function() {
                str += "<tbody><tr class='testRow'>";
                str += "<td class='id'>" + this['id'] + "</td>";
                str += "<td class='title'>" + this['title'] + "</td>";
                // str += "<td class='content'>" + this['content'] + "</td>";
                str += "<td class='sendingtime'>" + this['sendingtime'] + "</td>";
                str += "<td class='name'>" + this['name'] + "</td>";
                // str += "<td class='operation'><a href='page_announcement_manage.html' class='edit'>删除</a></td>";
                // str += "<td class='operation'><a href='' class='edit'>删除</a></td>";
                str += "<td class='operation'><span class='edit'>删除</span></td>";
                // str += "<td class='operation'><a href='JavaScript:void(0)' class='edit'>删除</a></td>";
                str += "</tr><tbody>"
            });
            $("#testTable").html(str);


            $(".testRow").bind("click"); //取消之前的绑定事件!!
            $(".testRow").click(function() {
                var id = $(this).children(".id").text();
                //var title = $(this).children(".title").text();
                console.log('id' + id);
                $('#Alltable').hide();
                showDetails(id);
                $('#details').show();
            });
     
            $(".operation").bind("click");
            $(".operation").click(function() {
                // 得到该条记录中的“name”信息
                var title = $(this).parent().children(".title").text();
                // alert("是否删除？");
                var r = confirm("确定要删除吗？");
                if (r == true) {
                    deleteannounce(title);
                }
                setTimeout(() => {
                    window.location.reload();
                }, 300);
                return false; //阻止冒泡，冒泡什么意思你自己查查os
            });

        }, //success
        error: function() {
            alert("error");
        }
    });
}

/*********************点击搜索按钮******************************/

//点击查询 只显示查询框的
function search(searchingword) {

    $("#searchannounce").bind("click");
    $("#searchannounce").click(function() {
           
            // $('#Alltable').hide();
            // $('#details').hide();
            // $('#searchingmore').show();
            ChangeTable(pageIndex, searchingword);

            function ChangeTable(pageIndex, searchingword) {
                $.ajax({
                    type: "POST",
                    url: "php/search_announcement.php",
                    dataType: "json",
                    sync: false,
                    //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
                    data: { index: pageIndex, size: pageSize, keyword: $("#searchs").val() },
                    success: function(data) {
                        $("#divtest").html("<table class='table table-hover' id='testTable'></table>");
                        // $("#divtest").html("<table class='table table-hover' id='testTable'></table>");
                        // 设置表格标题
                        // 设置为对应的teacher表
                        var str = "";
                        str += "<thead>"
                        str += "<th class='id'>序号</th>";
                        str += "<th class='title'>标题</th>";
                        // str += "<th class='content'>内容</th>";
                        str += "<th class='sendingtime'>发送时间</th>";
                        str += "<th class='name'>发布人</th>";
                        str += "<th class='operation'>操作</th>";
                        str += "</thead>";

                        // 设置表格内容
                        $.each(data, function() {
                            str += "<tbody><tr class='testRow'>";
                            str += "<td class='id'>" + this['id'] + "</td>";
                            str += "<td class='title'>" + this['title'] + "</td>";
                            // str += "<td class='content'>" + this['content'] + "</td>";
                            str += "<td class='sendingtime'>" + this['sendingtime'] + "</td>";
                            str += "<td class='name'>" + $("#searchs").val() + "</td>";
                            str += "<td class='operation'><span class='edit'>删除</span></td>";
                            // str += "<td class='operation'><a href='' class='edit'>删除</a></td>";
                            str += "</tr><tbody>"
                        });
                        $("#testTable").html(str);
                        $(".testRow").bind("click");
                        $(".testRow").click(function() {
                            // 得到该条记录中的“name”信息
                            var title = $(this).children(".title").text();
                            var id = $(this).children(".id").text();
                            console.log(title);
                            $('#Alltable').hide();
                            showDetails(title);
                            $('#details').show();
                        });
                        $(".operation").bind("click");
                        $(".operation").click(function() {
                            // 得到该条记录中的“name”信息
                            var title = $(this).parent().children(".title").text();
                            var r = confirm("确定要删除吗？");
                            if (r == true) {
                                deleteannounce(title);
                            }

                            // return false;
                        });

                    },
                    error: function() {
                        alert("error!!");
                    }
                }); //ajax结束
            } //changeTable结束


        }) //click结束
}

function back() {
    location.reload();


}

function getAnnounceTitle(title) {

    announcename = title;
    // alert(name);
    return announcename;
}


function showDetails(id) //啥意思啊 就 显示对应title的内容啊
{
    InitTable1(id);
}

//公告细节
function InitTable1(id) {
     $("#searchannounce").remove();
      $("#searchs").remove();
    getAnnounceTitle();
    console.log("1111");
    $.ajax({

        type: "POST",
        url: "php/announcement_showDb.php",
        dataType: "json",
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        // data: {index: pageIndex, size: pageSize,sendingname:name},
        data: { id: id }, // 提交数据                    
        success: function(data) {
            console.log(data);
            $("#divtest1").html("<div class = 'announcement' id = 'total'</div>");
            //设置为对应的announcement表
            var str = "";
            str += "<div class = 'title'></div>";
            str += "<div class = 'name'></div>";
            str += "<div class = 'sendingtime></div>";
            str += "<div class = 'content'></div>";

            //设置内容
            $.each(data, function() {
                str += "<div class = 'testRow'>";
                str += "<label>标题</label>";

                str += "<h4><div class = 'edit-title' contenteditable = 'true' style='background:white; padding:10px; border-radius:10px;border:1px solid grey;'>" + this['title'] + "</div></h4>";
                str += "<div class = 'name' >发布人： " + this['name'] + "</div>";
                str += '<div id="upload"><span style="top: 0px; left: 0px; position: absolute; cursor: pointer; width: 74px; height: 16px; overflow: hidden; background-color: rgb(255, 255, 255); zoom: 1; opacity: 0; z-index: 1;"><input type="file" title=" " id="UploadFile" name="UploadFile" multiple="" style="font-family: Times;position: absolute;cursor: pointer;width: 2000px;height: 600px;right: 0px;"></span><a class="compose_toolbtn_text ico_att" onclick="return false;" onmousedown="getTop().LogKV(`compose|toolbar|entrance|attach`);return false;" hidefocus=""><span id="sAddAtt1">添加附件</span></a><span class="editor_btn unselect qmEditorPhotoWrap" style="position: relative;"><a class="editor_btn_text qmEditorPhoto " style="position: relative;"><span style="top: 0px; left: 0px; position: absolute; cursor: pointer; width: 44px; height: 19px; overflow: hidden; background-color: rgb(255, 255, 255); zoom: 1; opacity: 0; z-index: 1;"><input type="file" title=" " name="UploadFile" id="InputFile" accept="image/gif,image/jpeg,image/png,image/pjpeg" multiple="" style="font-family: Times; position: absolute; cursor: pointer; width: 2000px; height: 600px; right: 0px;"></span>照片</a><span class="ico_moreupload" opt="more"></span></span></div>';
                // str += "<div class = 'sendingtime' contenteditable = 'true'>" + this['sendingtime'] + "</div>";
                
                str += "<h2><div class = 'edit-content' contenteditable = 'true' style='background:white;padding:10px; border-radius:10px;border:1px solid grey;'>" + this['content'] + "</div></h2>";
                str += "<div class = 'edit-attachment' >";
                if (this['file'] != null) {
                    str += "<a href='" + this['file'] + "' download='" +
                        this['file'].substring(this['file'].lastIndexOf('/') + 1) + "'>" +
                        this['file'].substring(this['file'].lastIndexOf('/') + 1) +
                        "</a>";
                }
                str += "</div>";
                str += "<div><button class='btn btn-success' id= 'submit_btn'>" + "确定修改" + "</button></div>";
                str += "</div>";
                $('.title').append(this['title']);


            });

            $("#total").html(str);
            edit(id);
        },
        error: function() {
            //alert("22222");
            alert("error");
        }
    });
}