$(document).ready(function(){
     var img=$.cookie("img");
      if(img!='null'){
         $("#img").attr("src", "uploadFile/"+img);
       }
    setInfo();
    setreadOnly();
        var canUpload;
      const GW_MAXFILESIZE = 2097152;
    //做个下简易的验证  大小 格式 
        $("#avatarInput").change(function() {
        $.each($('#avatarInput')[0].files, function(i, file) {
            if($('#avatarInput')[0].files!=null){
            var fileSize = $(this)[0].size;
            var fileType = $(this)[0].type;
            // 如果大小和类型符合要求
            if((fileType=='image/gif' || fileType=='image/jpeg' || fileType=='image/pjpeg' || fileType=='image/png') && (fileSize>0 && fileSize<GW_MAXFILESIZE)){
                canUpload = true;
            }
            else{
                alert("图像必须是 GIF, JPEG, 或者PNG格式, 文件大小不能超过2M!");
            }
        }
        });
        });
        var fileName;

        $("#pic_save").click(function() {
                if(canUpload==true){

                    var imgData = new FormData();
                    var img_lg = document.getElementById('imageHead');
                    // 截图小的显示框内的内容
                    html2canvas(img_lg, {
                        allowTaint: true,
                        taintTest: false,
                        onrendered: function(canvas) {
                            canvas.id = "mycanvas";
                            //生成base64图片数据
                            //
                            var dataUrl = canvas.toDataURL("image/jpeg");
                            imgData.append("screenshot", dataUrl);
                             var user_phone=$.cookie("phone");
                            imgData.append("phone", user_phone);

                            console.log(imgData.get('phone'));
                            console.log(imgData.get('screenshot'));
                            //js的路径查找是根据html来的
                            $.ajax({
                                url: 'php/addPicture.php',
                                type: 'POST',
                                data: imgData,
                                contentType: false,    //不可缺
                                processData: false,    //不可缺
                                success: function(jsonStr){
                                    var json = JSON.parse(jsonStr);
                                    if(json.status=='success'){
                                        alert("头像修改成功！");
                                        fileName=json.target;
                                        $.cookie("img",json.target, { expires: 1 });
                                        
                                        $("#img").attr("src", "uploadFile/"+json.target );
                                        $("#user img").attr("src", "uploadFile/"+json.target );
                                    }
                                    else if(json.status=='fail'){
                                        // $(".error").text(json.message); 
                                    }   
                                },
                                error: function(){
                                    alert("error");
                                }
                            }); // ajax上传头像结束
                              
                        }
                    });//html2canvas结束
    }//if事件结束
     else{
          alert("必须有图像，图像必须是 GIF, JPEG, 或者PNG格式, 文件大小不能超过2M!");
       }
            
});

        $("#save_info").click(function() {
            if($("#user_name").val()=="" || $("#user_password").val()==""){
                    alert("用户名与密码不能为空");
                    $('#user_name').focus();
                    return false;
            }
            if(isId($("#user_name").val().trim())){
                alert("用户名仅支持中英文、数字和下划线且长度为12以下，请重新输入");
                $('#user_name').focus();
                    return false;
            }
            if(isPassword($("#user_password").val().trim())){
                alert("密码长度为6~18位，请重新输入");
                $('#user_password').focus();
                return false;
            }
            if(isage($("#user_age").val().trim())){
                alert("请检查您的年龄");
                $('#user_age').focus();
                return false;
            }
                var r=confirm("确定要保存修改吗？");
                 if (r==true){
                    var formData = new FormData();
                    var username=$("#user_name").val();
                    var password=$("#user_password").val();
                    var age=$("#user_age").val();
                    var sex;
                    if($('#user_man').is(':checked')) 
                    { 
                        sex="男";
                    }
                    else{
                        sex="女";
                    }
                    console.log(sex);
                    var user_phone=$.cookie("phone");
                    formData.append("phone", user_phone);
                    formData.append('username', username);
                    formData.append('password', password);
                    formData.append('age', age);
                    formData.append('sex', sex);

                
                    $.ajax({
                        url: 'php/page_user.php',
                        type: 'POST',
                        data: formData,
                        contentType: false,    //不可缺
                        processData: false,    //不可缺
                        success: function(jsonStr){
                            var json = JSON.parse(jsonStr);
                            if(json.status=='success'){

                            }
                            else if(json.status=='fail'){

                            }   
                        },
                        error: function(){
                            alert("error");
                        }
                    }); // ajax修改信息结束
            }
        });
    $("#btn_ischange").click(function() {
        document.getElementById("user_name").readOnly=false;
        document.getElementById("user_password").readOnly=false;
        document.getElementById("user_age").readOnly=false;
        document.getElementById("user_man").disabled=false;
        document.getElementById("user_woman").disabled=false;       
    });



        function setreadOnly() {
            document.getElementById("user_phone").readOnly=true;
            document.getElementById("user_password").readOnly=true;
            document.getElementById("user_name").readOnly=true;
            document.getElementById("user_age").readOnly=true;
            document.getElementById("user_man").disabled=true;
            document.getElementById("user_woman").disabled=true;
        }

        function setInfo() {
            var info_phone=$.cookie("phone");
            var datas = {
                    "phone":info_phone
             };
             $.getJSON("php/getUserMessage.php",datas, function(json){
                 // getJSON已经帮我们转换成JSON对象了
                        if(json.status=='success'){
                                $('#user_password').val(json.password);
                                $('#user_name').val(json.username);
                                $.cookie('username',json.username);
                                $('#user_id').html(json.username);
                                $('#user_phone').val(info_phone);
                                $('#user_age').val(json.age);
                                if(json.sex=='男')
                                    $('#user_man').attr('checked', 'true');
                                else if(json.sex=='女')
                                    $('#user_woman').attr('checked', 'true');
                        }
                        else if(json.status=='fail'){
                            alert("加载信息项失败"); 
                        }   
               });



        }
        function isage(AGE) { 
            var tests = /^[0-9]{0,3}$/;
            if (!AGE.match(tests)) {
                return true;
            }
            return false;
        }
        function isPassword(PASSWORD) { 
            var tests = /\w{6,18}$/;
            if (!PASSWORD.match(tests)) {
                return true;
            }
            return false;
        }
          function isId(TEL) { 
            var names = /^[a-zA-Z0-9_\u4e00-\u9fa5]{0,12}$/;
            if (!TEL.match(names)) {
                return true;
            }
            return false;
        }

});