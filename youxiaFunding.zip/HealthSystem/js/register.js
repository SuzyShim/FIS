
 $("#signin button").click(function(){ 
    if($("#user_id").val()==""||$("#password").val()==""||$("#phone").val()==""){
        alert("请填写完整信息");
    } 
    else if(isPassword($("#password").val().trim())){
        alert("密码长度为6~18位，请重新输入");
        $('#password').focus();
    }
    else if($("#password").val()!=$("#re-password").val()){
        alert("两次密码输入不一致！请重新输入");
    }  
    else if(isId($("#user_id").val().trim())){
        alert("用户名仅支持中英文、数字和下划线且长度为12以下，请重新输入");
      $('#user_id').focus();
    }
    else if(!isphone($("#phone").val())){
        alert("请检查您的手机格式");
      $('#phone').focus();
    }
    else if($("#yes").is(':hidden')){
        alert("请阅读《健康管理协议》，感谢您的支持");
    }
    else{
        var datas = {
                "user":$("#user_id").val(),
                "phone":$("#phone").val(),
                "password":$("#password").val()
        };
        $.getJSON("php/register.php",datas, function(json){
                console.log(json);
         // getJSON已经帮我们转换成JSON对象了
                if(json.status=='success'){
                    alert("您已成功注册！"); 
                    $.cookie("password",$("#password").val(), { expires: 1 });   
                    $.cookie("phone",$("#phone").val(), { expires: 1 });
                    location.href="login.html";
                }
                else if(json.status=='fail'){
                    alert("该手机号已有账号，注册失败"); 
                }   
       });
    }

    });
  function isphone(TEL) {
         var reg =/^(13[0-9]{9})|(15[0-9]{9})|(17[0-9]{9})|(18[0-9]{9})|(19[0-9]{9})$/;
        if (TEL.match(reg)) {
            return true;
        }
        return false;
    }
      function isId(TEL) { 
        var names = /^[a-zA-Z0-9_\u4e00-\u9fa5]{0,12}$/;
        if (!names.test(TEL)) {
            return true;
        }
        return false;
    }function isPassword(TEL) { 
            var test = /^[a-zA-Z0-9_]{6,18}$/;
            if (!test.test(TEL)) {
                return true;
            }
            return false;
        }

