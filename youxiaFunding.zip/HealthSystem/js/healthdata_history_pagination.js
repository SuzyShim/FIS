var pageIndex = 1;    //页面索引初始值   
var pageSize = 10;     //每页显示条数初始化，修改显示条数，修改这里即可   
var pageCount = 30;   //总的记录数，随便赋个初值好了，后面会重新赋值的

$(document).ready(function () {
	// 得到要显示的总的记录数
	$.ajax({
		url: 'php/connectDB_healthdata.php',
		async: false,  // 取消异步，因为只有先得到总记录数，才能计算实际需要多少页
		type: 'POST',
		dataType: 'json',
		data: {index: '0', size: pageSize ,"phone":$.cookie("phone")}, // 提交数据
		success: function(data){
			 pageCount = data.total;
		},
		error: function() {
			alert("1111");
		}
	});
	
    InitTable(pageIndex);    //初始化表格数据
    InitPager();
});

function InitPager() {
    //分页，PageCount是总条目数，这是必选参数，其它参数都是可选
    $("#pager").pagination(pageCount, {
        callback: pageCallback,  //PageCallback() 为翻页调用次函数。
        prev_text: "上一页",
        next_text: "下一页",
        items_per_page: pageSize,
        num_edge_entries: 2,       //两侧首尾分页条目数
        num_display_entries: 3,    //连续分页主体部分分页条目数
        current_page: pageIndex - 1,   //当前页索引
    });
}
//翻页调用   
function pageCallback(index, jq) {
    InitTable(index + 1);
}
//请求数据   
function InitTable(pageIndex) {
    $.ajax({
        type: "POST",
        url: "php/connectDB_healthdata.php",
        dataType: "json",
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        data: {index: pageIndex, size: pageSize ,"phone":$.cookie("phone")},                    
        success: function (data) {
            $("#divtest").html("<table id='testTable'></table>");
            // 设置表格标题
            var str = "";
            str += "<tr>";
            str += "<th class=''>日期</th>";
            str += "<th class='weight'>体重(kg)</th>";
            str += "<th class='height'>身高(cm)</th>";
            str += "<th class='temp'>体温(°C)</th>";
            str += "<th class='bsuger_e'>空腹血糖(mmol/L)</th>";
            str += "<th class='bsuger_f'>餐后血糖(mmol/L)</th>";
            str += "<th class='bpressure_r'>舒张压(mmHg)</th>";
            str += "<th class='bpressure_s'>收缩压(mmHg)</th>";
            str += "<th class='hrate'>心率(次/分)</th>";
            str += "<th class='sportingtime'>运动时长(min)</th>";
            str += "</tr>";

            // 设置表格内容
            $.each(data, function(){
            	str += "<tr class='testRow'>";
                str += "<td class='date'>" + this['healthdata_date'] + "</td>";
                str += "<td class='weight'>" + this['healthdata_weight'] + "</td>";
                str += "<td class='height'>" + this['healthdata_height'] + "</td>";
                str += "<td class='temp'>" + this['healthdata_bodytemp'] + "</td>";
                str += "<td class='bsuger_e'>" + this['healthdata_bsuger_e'] + "</td>";
                str += "<td class='bsuger_f'>" + this['healthdata_bsuger_f'] + "</td>";
                str += "<td class='bpressure_r'>" + this['healthdata_bpressure_r'] + "</td>";
                str += "<td class='bpressure_s'>" + this['healthdata_bpressure_s'] + "</td>";
                str += "<td class='hrate'>" + this['healthdata_heartRate'] + "</td>";
                str += "<td class='sportingtime'>" + this['healthdata_sportingtime'] + "</td>";
                
                str += "</tr>";
            });
            $("#testTable").html(str);
            $(".edit").click(function(){
            	// 得到该条记录中的“first_name”信息
            	var date = $(this).parent().siblings(".date").text();
            	alert(date);
            });
        },
        error: function(e) {
			alert("2222");
            alert(e.responseText);
		}
    });
}

