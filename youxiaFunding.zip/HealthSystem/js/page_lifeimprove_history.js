var names=new Array("水果沙拉","蔬菜沙拉","小米粥","紫米粥","全麦面包","粗粮套餐","意面",
    "水果酸奶麦片","健康套餐1","健康套餐2");
var price=new Array("23","20","8","8","10","18","15","18","20","25");
var pageIndex = 1;    //页面索引初始值   
var pageSize = 3;     //每页显示条数初始化，修改显示条数，修改这里即可   
var pageCount = 0;   //总的记录数，随便赋个初值好了，后面会重新赋值的 
var user_id=$.cookie("phone");

// 得到要显示的总的记录数
	$.ajax({
		url: 'php/connectDb_listhistory.php',
		async: false,  // 取消异步，因为只有先得到总记录数，才能计算实际需要多少页
		type: 'POST',
		dataType: 'json',
		data: {index: '0', size: pageSize,user:user_id}, // 提交数据
		success: function(data){
			 pageCount = data.total;
		},
		error: function() {
			alert("error");
		}
	});

addlist();
pageIndex++;
$(window).scroll(function(){
            
        var windowHeight = $(window).height();//当前窗口的高度             
        var scrollTop = $(window).scrollTop();//当前滚动条从上往下滚动的距离            
        var docHeight = $(document).height(); //当前文档的高度 
        console.log(scrollTop, windowHeight, docHeight);
        //当 滚动条距底部的距离 + 滚动条滚动的距离 >= 文档的高度 - 窗口的高度  
        //换句话说：（滚动条滚动的距离 + 窗口的高度 = 文档的高度）  这个是基本的公式  
        if (scrollTop + windowHeight >= docHeight-50) { 
        	console.log(pageIndex-1);
        	console.log(pageSize);
        	console.log(pageCount);
			if((pageIndex-1)*pageSize<pageCount){
			$('#loading').css('display','block');
				addlist();
				pageIndex++;
			$('#loading').css('display','none');
			}
        }//if结束
    });//滚动结束

	function btn_delete(strs){
 		var r=confirm("确定删除吗？");
             if (r==true){

			//加载listdetails
            $.ajax({
				        type: "POST",
				        url: "php/delete_orderhistory.php",
				        dataType: "json",
				        async: false,  // 取消异步
				        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
				        data: {order_id: strs},                    
				        success: function (data) {
				        	$.each(data, function(){
            					location.reload();
				            });
				        },
				        error: function() {
							alert("删除失败");
						}
				});//加载listdetails结束
        }
	}
	function addlist() {
		// 通过ajax加载数据
	$.ajax({
        type: "POST",
        url: "php/connectDb_listhistory.php",
        dataType: "json",
		async: false,  // 取消异步
        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
        data: {index: pageIndex, size: pageSize, user:user_id},                    
        success: function (data) {
        	var i=0;
        	$.each(data, function(){
        	var strs = "";
            strs += "<div class='ordertitle'>"
            strs += "<span style='font-weight: bold;'>"+this['order_time']+"</span><span style='margin-left: 5px;'>订单号："+this['order_id']+"</span>";
            strs += "<span style='color: #BB5564; margin-left: 5px;'>"+this['state']+"</span>";
            strs += "<a class='delete' style='margin-left:5px;'onclick='btn_delete("+this['order_id']+")'>删除</a>";
            strs += "<a data-toggle='modal' data-target='#avatar-modal"+i+"'>订单详情</a>";
            strs += "</div>";

// <!--模态框-->
            strs +="<div class='modal movefade movemodal' id='avatar-modal"+i+"'>";
            strs +="<div class='modal-dialog'>";
            strs +="<div class='modal-content'>";
            strs +="<div class='modal-header'><h4>订单详情</h4></div>";
            strs +="<div class='modal-body'>";
            strs +="<table><tr><th>订单号：</th><th>"+this['order_id']+"</th></tr>";
            strs +="<tr><th>下单时间：</th><th>"+this['order_time']+"</th></tr>";
            strs +="<tr><th>订单地址：</th><th>"+this['address']+"</th></tr>";
            strs +="<tr><th>接收人：</th><th>"+this['name']+"</th></tr>";
            strs +="<tr><th>电话：</th><th>"+this['phone']+"</th></tr>";
            strs +="<tr><th>总价：</th><th>"+this['tot_price']+"</th></tr>";
            strs +="</table></div>";
            strs +="<div class='modal-footer' style='text-align: center;'><button class='btn btn-default' data-dismiss='modal'>确定</button></div>";
            strs +="</div></div></div>";
  // <!--模态框结束-->
            $(".list").append(strs);
            i++;
				        		console.log(this['order_id']);

			//加载listdetails
            $.ajax({
				        type: "POST",
				        url: "php/orderhistory.php",
				        dataType: "json",
				        async: false,  // 取消异步
				        //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
				        data: {index: this['order_id']},                    
				        success: function (data) {
				        	$.each(data, function(){
				            var food_id=this['food_id'];
				        	var strs = "";
				        	var img=parseFloat(food_id)+1;
				            strs += "<li><div class='item'><div class='item-left'>"
				            strs += "<div class='item-img'><img src='images/"+img+".jpg'></div>";
				            strs += "</div><div class='item-right'><div class='title'>"+names[food_id]+"</div>";
				            strs += "<div class='price'>￥"+price[food_id]+" * "+this['num']+"</div></div></div></li>";
				            $(".list").append(strs);
				            });
				        },
				        error: function() {
							// alert("error");
						}
				});//加载listdetails结束
            });//each结束
        },
        error: function() {
			// alert("error");
		}
});//ajax结束

}

