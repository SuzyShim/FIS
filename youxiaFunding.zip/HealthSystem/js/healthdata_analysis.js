$date=new Array(5);
$weight= new Array(5);
$height= new Array(5);
$bpressure_r=new Array(5);
$bpressure_s=new Array(5);
$bsuger_e=new Array(5);
$bsuger_f=new Array(5);
$bodytemp=new Array(5);
$isHealthy=new Array(5);
$sporttime=new Array(5);
$sportsPlan=new Array(5);
$eatingPlan=new Array(5);
/*$bsuger_f[0]=1;
alert($bsuger_f[0]);*/

$.ajax({
    type: "POST",
    url: "php/healthdata_analysis.php",
    dataType: "json",
    async: false,
    //提交两个参数：pageIndex(页面索引)，pageSize(显示条数)
    data: {"phone":$.cookie("phone")},                    
    success: function (data) {
        $.each(data, function(index){
            $date[index]=this['healthdata_date'].substring(5);
            $bpressure_r[index]=this['healthdata_bpressure_r'];
            $bpressure_s[index]=this['healthdata_bpressure_s'];
            $bsuger_e[index]=this['healthdata_bsuger_e'];
            $bsuger_f[index]=this['healthdata_bsuger_f'];
            $bodytemp[index]=this['healthdata_bodytemp'];
            $isHealthy[index]=this['healthdata_isHealthy'];
            $sporttime[index]=this['healthdata_sportingtime'];
            $weight[index]=this['healthdata_weight'];
            $height[index]=this['healthdata_height'];
            $sportsPlan[index]=this['healthdata_sportsPlan'];
            $eatingPlan[index]=this['healthdata_eatingPlan'];

  

        });    
        
    },
    error: function(e) {
        /*alert("failed");*/
        alert(e.responseText);
    }
});

var sportlist = $sportsPlan[0].split("；");
var foodlist = $eatingPlan[0].split("；");
    for(var i =0;i<foodlist.length;i++){
     $("#eatingplan").append("<li>"+foodlist[i]+"</li>");

    }
 for(var i =0;i<sportlist.length;i++){
     $("#sportsplan").append("<li>"+sportlist[i]+"</li>");

    }
//求血糖平均值和最大值
/*$bsuger_e_max=Math.max.apply(null,$bsuger_e);
$temp_sum=0;
for(var i=0;i<5;i++)
{
    $temp_sum+=parseFloat($bsuger_e[i]);
}

$bsuger_e_avg=($temp_sum/$bsuger_e.length).toFixed(2);*/
/*alert($temp_sum);
alert($bsuger_e.length);
alert($bsuger_e_avg);*/

/*if($bsuger_e[0]>6.1)
{
    $eatingPlan="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;血糖高，饮食应该注意，最好是分餐制，每天三餐，每餐主食不要超过100克，不要吃高热量的食物，比如油条、油炸糕，这一类食物不要吃。其次不要喝饮料，血糖高尽量不要喝粥，多以干饭为主，其次要多进食富含蛋白质及维生素丰富的食物。地瓜、土豆、粉条这一类含淀粉的食物尽量要少吃。";
}

//求bmi指数
$bmi=($weight[0]/($height[0]/10000*$height[0])).toFixed(1);
if($bmi>23.8)
{
    $sportPlan="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;合理分配运动量和变换运动方式。如果在健身房运动的话，最好的程序是跑步机(或单车)、局部力量练习、跳操(或游泳)，每个项目锻炼时间在10～20分钟为佳。使身体更多部位参与运动,如果是在户外进行健身运动，最好先慢跑10～15分钟，然后进行一些腰腹锻炼、单项体育活动(如球类、跳绳、健身器材等)，再进行一些球类或健身器材运动时，最好保证锻炼方式多样化，尽量使身体更多部位参与运动。";
}*/

/*document.getElementById("sportPlan_data").innerHTML=$sportPlan;

document.getElementById("eatingPlan_data").innerHTML=$eatingPlan;
*/
// 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('xueya'));
 
        // 指定图表的配置项和数据
        option = {
            title: {
                text: '近五天血压情况',
                textStyle: {//主标题文本样式{"fontSize": 18,"fontWeight": "bolder","color": "#333"}
                  fontSize: 16,                
                },

            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['舒张压', '收缩压']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: [$date[0],$date[1],$date[2],$date[3],$date[4]]
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name: '舒张压',
                    type: 'line',
                    stack: '总量',
                    data: [$bpressure_r[0],$bpressure_r[1],$bpressure_r[2],$bpressure_r[3],$bpressure_r[4]]
                },
                {
                    name: '收缩压',
                    type: 'line',
                    stack: '总量',
                    data: [$bpressure_s[0],$bpressure_s[1],$bpressure_s[2],$bpressure_s[3],$bpressure_s[4]]
                }
            ]
        };
        //70, 75, 90, 85, 80
        //110, 105, 130, 120, 125
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);

        var myChart = echarts.init(document.getElementById('bsuger'));
 
        // 指定图表的配置项和数据
        option = {
            title: {
                text: '近五天血糖情况',
                textStyle: {//主标题文本样式{"fontSize": 18,"fontWeight": "bolder","color": "#333"}
                  fontSize: 14,                
                },

            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['空腹', '餐后']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: [$date[0],$date[1],$date[2],$date[3],$date[4]]
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name: '空腹',
                    type: 'line',
                    stack: '总量',
                    data: [$bsuger_e[0],$bsuger_e[1],$bsuger_e[2],$bsuger_e[3],$bsuger_e[4]]
                },
                {
                    name: '餐后',
                    type: 'line',
                    stack: '总量',
                    data: [$bsuger_f[0],$bsuger_f[1],$bsuger_f[2],$bsuger_f[3],$bsuger_f[4]]
                }
            ]
        };
 
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);

        var myChart = echarts.init(document.getElementById('bodytemp'));
 
        // 指定图表的配置项和数据
        option = {
            title: {
                text: '近五天体温情况',
                textStyle: {//主标题文本样式{"fontSize": 18,"fontWeight": "bolder","color": "#333"}
                  fontSize: 14,                
                },
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['空腹']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: [$date[0],$date[1],$date[2],$date[3],$date[4]]
            },
            yAxis: {
                type: 'value'
            },
            series: [
                
                {
                    name: '体温',
                    type: 'line',
                    stack: '总量',
                    data: [$bodytemp[0],$bodytemp[1],$bodytemp[2],$bodytemp[3],$bodytemp[4]]
                }
            ]
        };
        myChart.setOption(option);
        //36.1, 36.5, 36.2, 36.4, 36.0
        //'5.27', '5.28', '5.29', '5.30', '5.31'
        
        //计算isHealthy数组中0,1出现的次数；
        $count0=0;
        $count1=0;
        for(var i=0;i<5;i++)
        {
            if($isHealthy[i]==1)
                $count1++;
            else
                $count0++;
        }
        
        var myChart = echarts.init(document.getElementById('healthydays'));
        option = {
              title: {
                  text: '近五天健康情况',
                  textStyle: {//主标题文本样式{"fontSize": 18,"fontWeight": "bolder","color": "#333"}
                  fontSize: 16,                
                },
                  left: 'center'
              },
              tooltip: {
                  trigger: 'item',
                  formatter: '{a} <br/>{b} : {c} ({d}%)'
              },
              legend: {
                  orient: 'vertical',
                  left: 'left',
                  data: ['健康天数','不健康天数']
              },
              color : [ '#72A376', '#DD2C00'],
              series: [
                  {
                      name: '访问来源',
                      type: 'pie',
                      radius: '55%',
                      center: ['50%', '60%'],
                      data: [
                          
                          {value: $count1, name: '健康天数'},
                          {value: $count0, name: '不健康天数'}
                      ],
                      emphasis: {
                          itemStyle: {
                              shadowBlur: 10,
                              shadowOffsetX: 0,
                              shadowColor: 'rgba(0, 0, 0, 0.5)'
                          }
                      }
                  }
              ]
          };
          myChart.setOption(option);