/*
Navicat MySQL Data Transfer

Source Server         : javaClass
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : web

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2020-06-15 20:23:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `announcement`
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `sendingtime` varchar(20) NOT NULL,
  `title` varchar(30) NOT NULL,
  `name` varchar(20) NOT NULL,
  `file` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of announcement
-- ----------------------------
INSERT INTO `announcement` VALUES ('51', '<div>还没写完的赶紧呀！</div><div><br></div><img src=\"uploadFile/announcementPic/1592073080365TIM图片20200614022812.jpg\" data-index=\"0\" class=\"uploadedPic\">', '2020-06-13 20:31:20', 'web作业要截止啦', '66666', 'uploadFile/announcementPic/1592073080时间计划安排.docx');
INSERT INTO `announcement` VALUES ('52', '泪目<div><img src=\"uploadFile/announcementPic/1592073159373TIM图片20200614023223.jpg\" data-index=\"0\" class=\"uploadedPic\"></div>', '2020-06-13 20:37:06', '数据库也要挂科了', '66666', 'uploadFile/announcementPic/1592073426《算法分析与设计》期末大作业_V2020052302.docx');
INSERT INTO `announcement` VALUES ('53', '<img src=\"uploadFile/announcementPic/1592073472487TIM图片20200614023223.jpg\" data-index=\"0\" class=\"uploadedPic\">', '2020-06-13 20:37:52', '准备好考试了吗', '66666', '');
INSERT INTO `announcement` VALUES ('54', '<img src=\"uploadFile/announcementPic/159207356576136C294437EC6CAB7EBB6EA93FF105C41.png\" data-index=\"0\" class=\"uploadedPic\">', '2020-06-13 20:39:25', '重点来了', '66666', 'uploadFile/announcementPic/1592073565《应用密码学》2018-2019期末考试A答案与评分标准.doc');
INSERT INTO `announcement` VALUES ('55', '<img src=\"uploadFile/announcementPic/1592073641769ABEC475124670053E3B8B53554A51846.png\" data-index=\"1\" class=\"uploadedPic\">', '2020-06-13 20:40:41', '我人晕了', '66666', null);
INSERT INTO `announcement` VALUES ('56', '<div>健康饮食，健康生活每一天</div><div><img src=\"uploadFile/announcementPic/15921151479443.jpg\" data-index=\"0\" class=\"uploadedPic\"></div>', '2020-06-14 09:25:22', '今天的午餐', '李华', null);
INSERT INTO `announcement` VALUES ('57', '见附件', '2020-06-14 08:12:55', '五谷杂粮', '2018', 'uploadFile/announcementPic/15921151756.jpg');

-- ----------------------------
-- Table structure for `mune`
-- ----------------------------
DROP TABLE IF EXISTS `mune`;
CREATE TABLE `mune` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `food_name` varchar(32) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `img` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mune
-- ----------------------------
INSERT INTO `mune` VALUES ('1', '水果沙拉', '23.00', '1.jpg');
INSERT INTO `mune` VALUES ('2', '蔬菜沙拉', '20.00', '2.jpg');
INSERT INTO `mune` VALUES ('3', '小米粥', '8.00', '3.jpg');
INSERT INTO `mune` VALUES ('4', '紫米粥', '8.00', '4.jpg');
INSERT INTO `mune` VALUES ('5', '全麦面包', '10.00', '5.jpg');
INSERT INTO `mune` VALUES ('6', '粗粮套餐', '18.00', '6.jpg');
INSERT INTO `mune` VALUES ('7', '水果酸奶麦片', '15.00', '7.jpg');
INSERT INTO `mune` VALUES ('8', '健康套餐1', '18.00', '8.jpg');
INSERT INTO `mune` VALUES ('9', '健康套餐2', '20.00', '9.jpg');
INSERT INTO `mune` VALUES ('10', '意面', '25.00', '10.jpg');

-- ----------------------------
-- Table structure for `orderlist`
-- ----------------------------
DROP TABLE IF EXISTS `orderlist`;
CREATE TABLE `orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(32) NOT NULL,
  `order_time` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(15) DEFAULT NULL,
  `user` varchar(15) DEFAULT NULL,
  `state` varchar(5) DEFAULT NULL,
  `address` varchar(64) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `tot_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderlist
-- ----------------------------
INSERT INTO `orderlist` VALUES ('1', '15171285986', '2020-06-05 00:31:46', '张先生', '13580000000', '已接收', '吉林省长春市南关区213', '13355551334', '26.00');
INSERT INTO `orderlist` VALUES ('2', '15171285995', '2020-06-05 00:32:11', '张先生', '13580000000', '已接收', '吉林省长春市南关区213', '13355551334', '62.00');
INSERT INTO `orderlist` VALUES ('3', '15171287453', '2020-06-05 00:32:08', '李女士', '13580000000', '运送中', '北京市北京市市辖区东城区2132', '13352343253', '115.00');
INSERT INTO `orderlist` VALUES ('4', '15171287518', '2020-06-05 00:32:04', '李女士', '13580000000', '运送中', '河北省石家庄市长安区3123', '13355555555', '84.00');
INSERT INTO `orderlist` VALUES ('5', '15171287545', '2020-06-05 00:32:24', '李女士', '13580000000', '待取餐', '北京市北京市市辖区东城区13213', '13355555555', '84.00');
INSERT INTO `orderlist` VALUES ('6', '15171287551', '2020-06-05 00:32:27', '李女士', '13580000000', '待取餐', '北京市北京市市辖区东城区13213', '13355554242', '84.00');
INSERT INTO `orderlist` VALUES ('8', '15180166365', '2020-06-04 21:55:03', '李女士', '13588887462', '待发货', '天津市天津市市辖区和平区1231', '13355555555', '184.00');
INSERT INTO `orderlist` VALUES ('9', '15180166374', '2020-06-04 21:55:12', '李先生', '13588887462', '待发货', '天津市天津市市辖区和平区1231', '13355555555', '184.00');
INSERT INTO `orderlist` VALUES ('10', '15180166380', '2020-06-04 21:55:18', '李先生', '13588887462', '待发货', '辽宁省沈阳市和平区1231', '13355555555', '184.00');
INSERT INTO `orderlist` VALUES ('11', '15180166385', '2020-06-04 21:55:23', '李先生', '13588887462', '待发货', '浙江省杭州市上城区1231', '13355555555', '184.00');
INSERT INTO `orderlist` VALUES ('12', '15180309489', '2020-06-06 13:40:27', '李先生', '13588887462', '已接单', '北京市北京市市辖区房山区QWE', '13352343253', '18.00');
INSERT INTO `orderlist` VALUES ('13', '15180317151', '2020-06-06 15:48:09', '李女士', '13588887462', '已接单', '黑龙江省哈尔滨市道里区123', '13352343253', '38.00');
INSERT INTO `orderlist` VALUES ('15', '15180328710', '2020-06-06 19:00:48', '李女士', '13588887462', '已接单', '北京市北京市市辖区东城区23', '13355555555', '132.00');
INSERT INTO `orderlist` VALUES ('16', '15180958044', '2020-06-14 01:49:42', '李女士', '13588887462', '已接单', '北京市北京市市辖区东城区111', '13355555555', '82.00');
INSERT INTO `orderlist` VALUES ('17', '14925448435', '2020-06-14 14:11:42', '刘小姐', '13333333333', '已接单', '北京市北京市市辖区东城区123', '13355555555', '58.00');

-- ----------------------------
-- Table structure for `orderlistdetails`
-- ----------------------------
DROP TABLE IF EXISTS `orderlistdetails`;
CREATE TABLE `orderlistdetails` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(12) NOT NULL,
  `num` int(2) DEFAULT NULL,
  `food_id` varchar(32) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderlistdetails
-- ----------------------------
INSERT INTO `orderlistdetails` VALUES ('19', '1591212578', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('20', '1591212578', '3', '1');
INSERT INTO `orderlistdetails` VALUES ('21', '1591212578', '8', '2');
INSERT INTO `orderlistdetails` VALUES ('22', '1591212578', '2', '3');
INSERT INTO `orderlistdetails` VALUES ('23', '1591212582', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('24', '1591212582', '3', '1');
INSERT INTO `orderlistdetails` VALUES ('25', '1591212582', '8', '2');
INSERT INTO `orderlistdetails` VALUES ('26', '1591212582', '2', '3');
INSERT INTO `orderlistdetails` VALUES ('31', '15180166365', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('32', '15180166365', '3', '4');
INSERT INTO `orderlistdetails` VALUES ('33', '15180166365', '3', '6');
INSERT INTO `orderlistdetails` VALUES ('34', '15180166365', '2', '8');
INSERT INTO `orderlistdetails` VALUES ('35', '15180166374', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('36', '15180166374', '3', '4');
INSERT INTO `orderlistdetails` VALUES ('37', '15180166374', '3', '6');
INSERT INTO `orderlistdetails` VALUES ('38', '15180166374', '2', '8');
INSERT INTO `orderlistdetails` VALUES ('39', '15180166380', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('40', '15180166380', '3', '4');
INSERT INTO `orderlistdetails` VALUES ('41', '15180166380', '3', '6');
INSERT INTO `orderlistdetails` VALUES ('42', '15180166380', '2', '8');
INSERT INTO `orderlistdetails` VALUES ('43', '15180166385', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('44', '15180166385', '3', '4');
INSERT INTO `orderlistdetails` VALUES ('45', '15180166385', '3', '6');
INSERT INTO `orderlistdetails` VALUES ('46', '15180166385', '2', '8');
INSERT INTO `orderlistdetails` VALUES ('47', '15171285986', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('48', '15171285986', '1', '5');
INSERT INTO `orderlistdetails` VALUES ('49', '15171285995', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('50', '15171285995', '3', '5');
INSERT INTO `orderlistdetails` VALUES ('51', '15171287453', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('52', '15171287453', '3', '5');
INSERT INTO `orderlistdetails` VALUES ('53', '15171287453', '1', '6');
INSERT INTO `orderlistdetails` VALUES ('54', '15171287453', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('55', '15171287453', '1', '8');
INSERT INTO `orderlistdetails` VALUES ('56', '15171287518', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('57', '15171287518', '1', '5');
INSERT INTO `orderlistdetails` VALUES ('58', '15171287518', '1', '6');
INSERT INTO `orderlistdetails` VALUES ('59', '15171287518', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('60', '15171287518', '1', '9');
INSERT INTO `orderlistdetails` VALUES ('61', '15171287545', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('62', '15171287545', '1', '5');
INSERT INTO `orderlistdetails` VALUES ('63', '15171287545', '1', '6');
INSERT INTO `orderlistdetails` VALUES ('64', '15171287545', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('65', '15171287545', '1', '9');
INSERT INTO `orderlistdetails` VALUES ('66', '15171287551', '1', '2');
INSERT INTO `orderlistdetails` VALUES ('67', '15171287551', '1', '5');
INSERT INTO `orderlistdetails` VALUES ('68', '15171287551', '1', '6');
INSERT INTO `orderlistdetails` VALUES ('69', '15171287551', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('70', '15171287551', '1', '9');
INSERT INTO `orderlistdetails` VALUES ('71', '15180309489', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('72', '15180317151', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('73', '15180317151', '1', '8');
INSERT INTO `orderlistdetails` VALUES ('77', '15180328710', '3', '0');
INSERT INTO `orderlistdetails` VALUES ('78', '15180328710', '3', '6');
INSERT INTO `orderlistdetails` VALUES ('79', '15180328710', '1', '7');
INSERT INTO `orderlistdetails` VALUES ('80', '15180958044', '2', '0');
INSERT INTO `orderlistdetails` VALUES ('81', '15180958044', '2', '5');
INSERT INTO `orderlistdetails` VALUES ('82', '14925448435', '1', '0');
INSERT INTO `orderlistdetails` VALUES ('83', '14925448435', '1', '1');
INSERT INTO `orderlistdetails` VALUES ('84', '14925448435', '1', '6');

-- ----------------------------
-- Table structure for `personal_healthdata`
-- ----------------------------
DROP TABLE IF EXISTS `personal_healthdata`;
CREATE TABLE `personal_healthdata` (
  `phone` varchar(20) NOT NULL,
  `healthdata_date` date NOT NULL,
  `healthdata_height` varchar(100) DEFAULT NULL,
  `healthdata_weight` varchar(100) DEFAULT NULL,
  `healthdata_bodytemp` varchar(100) DEFAULT NULL,
  `healthdata_bpressure_r` varchar(100) DEFAULT NULL,
  `healthdata_bpressure_s` varchar(100) DEFAULT NULL,
  `healthdata_bsuger_e` varchar(100) DEFAULT NULL,
  `healthdata_bsuger_f` varchar(100) DEFAULT NULL,
  `healthdata_heartRate` varchar(100) DEFAULT NULL,
  `healthdata_isHealthy` int(100) DEFAULT NULL,
  `healthdata_sportsPlan` varchar(200) DEFAULT NULL,
  `healthdata_eatingPlan` varchar(200) DEFAULT NULL,
  `healthdata_sportingtime` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`healthdata_date`,`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of personal_healthdata
-- ----------------------------
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-05-27', '175', '59.9', '35.9', '69', '115', '5.9', '7.2', '70', '1', '注意运动。', '注意饮食。', '1');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-05-28', '175', '59.8', '36.8', '72', '119', '6.5', '6.9', '72', '1', '注意运动。', '注意饮食。', '2');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-05-29', '175', '60.5', '36.1', '71', '120', '6.4', '6.5', '69', '1', '注意运动。', '注意饮食。', '3');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-05-30', '175', '60.1', '36.2', '75', '110', '6.1', '7.0', '75', '1', '注意运动。', '注意饮食。', '4');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-05-31', '175', '60.2', '36.5', '70', '105', '5.9', '7.1', '76', '1', '注意运动。', '注意饮食。', '3');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-06-13', '140', '60.2', '36.5', '70', '105', '5.9', '7.1', '76', '0', '拉伸20min；快走40分钟；慢跑20min；6组平板支撑40s/组；拉伸20min', '早餐：玉米面窝窝头、牛奶（或豆奶）、卤五香茶蛋１个、豆腐乳（１／４块）；\r\n    水果：枇杷（或长生果）３～４个；\r\n    中餐：花生米饭、肉末茄子、葱花土豆泥、鸭子海带汤；\r\n    晚餐：干煸豆角、稀饭、豆沙包、青椒肉丝', '3');
INSERT INTO `personal_healthdata` VALUES ('13300380038', '2020-06-14', '150', '80', '36.5', '70', '105', '60.00', '7.1', '76', '0', '拉伸20min；快走40分钟；慢跑20min；6组平板支撑40s/组；拉伸20min', '早餐：酱肉包、牛奶（或豆奶）、素炒三丝（莴笋、白萝卜、胡萝卜）、鹌鹑蛋２个；\r\n    水果：猕猴桃（或桃子）１～２个；\r\n    中餐：红豆米饭、魔芋烧鸭、红椒炒花菜、鱼头香菇冬笋青菜汤；\r\n    晚餐：芹菜猪肉包子、西红柿炒鸡蛋、肉末豆腐脑', '3');
INSERT INTO `personal_healthdata` VALUES ('13312312311', '2020-06-14', '150', '80', '60.0', '70', '105', '5.9', '7.1', '76', '0', '拉伸20min；慢跑20min；游泳20min；5组仰卧起坐12个/组；拉伸20min', '早餐：玉米面窝窝头、牛奶（或豆奶）、卤五香茶蛋１个、豆腐乳（１／４块）；\r\n    水果：枇杷（或长生果）３～４个；\r\n    中餐：花生米饭、肉末茄子、葱花土豆泥、鸭子海带汤；\r\n    晚餐：干煸豆角、稀饭、豆沙包、青椒肉丝', '3');
INSERT INTO `personal_healthdata` VALUES ('13588887462', '2020-06-14', '140', '60.2', '36.5', '70', '105', '5.9', '7.1', '76', '0', '拉伸20min；快走40分钟；慢跑20min；6组平板支撑40s/组；拉伸20min', '早餐：玉米面窝窝头、牛奶（或豆奶）、卤五香茶蛋１个、豆腐乳（１／４块）；\r\n    水果：枇杷（或长生果）３～４个；\r\n    中餐：花生米饭、肉末茄子、葱花土豆泥、鸭子海带汤；\r\n    晚餐：干煸豆角、稀饭、豆沙包、青椒肉丝', '3');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `phone` varchar(13) NOT NULL,
  `user` varchar(12) NOT NULL,
  `password` varchar(64) NOT NULL DEFAULT '88888888' COMMENT '初始密码8个8',
  `age` varchar(3) DEFAULT NULL,
  `img` varchar(64) DEFAULT NULL,
  `sex` varchar(1) DEFAULT '',
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('13312312311', '201', '123456', '1', 'null', '女');
INSERT INTO `user` VALUES ('13333323223', '232', '123456', '', 'null', '');
INSERT INTO `user` VALUES ('13333333333', '八宝粥', '123456', '23', '1592117633682.jpg', '男');
INSERT INTO `user` VALUES ('13365646465', '李华', '123456', null, 'null', '');
INSERT INTO `user` VALUES ('13555555555', '66666', '123456', null, 'null', '');
INSERT INTO `user` VALUES ('13580000000', '2333', '123456', null, '1591288541875.jpg', '');
INSERT INTO `user` VALUES ('13588887462', '66666', '123456', null, '1592066698415.jpg', '');
